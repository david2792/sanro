from django.core.exceptions import ValidationError
from django.db import models

from personas.models import Alumno, Docente


class Institucion(models.Model):
    nombre = models.CharField(max_length=200)
    codigo_mec = models.CharField("Código MEC", max_length=20, blank=True)
    direccion = models.CharField(max_length=200, blank=True)
    ciudad = models.CharField(max_length=100, blank=True)
    departamento = models.CharField(max_length=100, blank=True)
    telefono = models.CharField(max_length=30, blank=True)
    asistencia_minima = models.PositiveSmallIntegerField(
        "Asistencia mínima (%)", default=80,
        help_text="Porcentaje mínimo de asistencia exigido a los alumnos.",
    )

    class Meta:
        verbose_name_plural = "instituciones"

    def __str__(self):
        return self.nombre


class AnioLectivo(models.Model):
    anio = models.PositiveSmallIntegerField("Año", unique=True)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    activo = models.BooleanField(default=False)

    class Meta:
        ordering = ["-anio"]
        verbose_name = "año lectivo"
        verbose_name_plural = "años lectivos"

    def save(self, *args, **kwargs):
        # Solo puede haber un año lectivo activo.
        if self.activo:
            AnioLectivo.objects.exclude(pk=self.pk).update(activo=False)
        super().save(*args, **kwargs)

    @classmethod
    def actual(cls):
        return cls.objects.filter(activo=True).first()

    def __str__(self):
        return str(self.anio)


class Etapa(models.Model):
    anio_lectivo = models.ForeignKey(AnioLectivo, on_delete=models.CASCADE, related_name="etapas")
    numero = models.PositiveSmallIntegerField()
    nombre = models.CharField(max_length=50, default="Etapa")
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()

    class Meta:
        ordering = ["anio_lectivo", "numero"]
        unique_together = ("anio_lectivo", "numero")

    def __str__(self):
        return f"{self.numero}ª {self.nombre} {self.anio_lectivo}"


class DiaNoLectivo(models.Model):
    """Feriados, asuetos y suspensiones. No cuentan para la asistencia."""

    anio_lectivo = models.ForeignKey(AnioLectivo, on_delete=models.CASCADE, related_name="dias_no_lectivos")
    fecha = models.DateField()
    motivo = models.CharField(max_length=150)

    class Meta:
        ordering = ["fecha"]
        unique_together = ("anio_lectivo", "fecha")
        verbose_name = "día no lectivo"
        verbose_name_plural = "días no lectivos"

    def __str__(self):
        return f"{self.fecha} - {self.motivo}"


class Nivel(models.Model):
    """Ej.: Educación Escolar Básica (3er ciclo), Educación Media."""

    nombre = models.CharField(max_length=100, unique=True)
    orden = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["orden"]
        verbose_name_plural = "niveles"

    def __str__(self):
        return self.nombre


class Especialidad(models.Model):
    """Ej.: Bachillerato Científico con énfasis en Ciencias Sociales, Bachillerato Técnico en..."""

    nivel = models.ForeignKey(Nivel, on_delete=models.PROTECT, related_name="especialidades")
    nombre = models.CharField(max_length=150)

    class Meta:
        ordering = ["nivel", "nombre"]
        verbose_name_plural = "especialidades"

    def __str__(self):
        return self.nombre


class Curso(models.Model):
    """Grado/curso de un plan: '7° grado' (EEB) o '1° curso - Bachillerato Científico' (EM)."""

    nivel = models.ForeignKey(Nivel, on_delete=models.PROTECT, related_name="cursos")
    especialidad = models.ForeignKey(
        Especialidad, null=True, blank=True, on_delete=models.PROTECT, related_name="cursos"
    )
    grado = models.PositiveSmallIntegerField()
    nombre = models.CharField(max_length=100, help_text="Ej.: 1° Curso, 9° Grado")

    class Meta:
        ordering = ["nivel__orden", "grado"]
        unique_together = ("nivel", "especialidad", "grado")

    def __str__(self):
        return f"{self.nombre} {self.especialidad or self.nivel}"


class Materia(models.Model):
    nombre = models.CharField(max_length=100, unique=True)
    abreviatura = models.CharField(max_length=15, blank=True)

    class Meta:
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre


class PlanMateria(models.Model):
    """Materias de cada curso según el plan de estudios (plan común / específico)."""

    class Tipo(models.TextChoices):
        COMUN = "COMUN", "Plan común"
        ESPECIFICO = "ESPECIFICO", "Plan específico"

    curso = models.ForeignKey(Curso, on_delete=models.CASCADE, related_name="plan")
    materia = models.ForeignKey(Materia, on_delete=models.PROTECT)
    tipo = models.CharField(max_length=10, choices=Tipo.choices, default=Tipo.COMUN)
    horas_semanales = models.PositiveSmallIntegerField(default=2)

    class Meta:
        unique_together = ("curso", "materia")
        verbose_name = "materia del plan"
        verbose_name_plural = "plan de estudios"

    def __str__(self):
        return f"{self.curso} - {self.materia}"


class Seccion(models.Model):
    """Un curso concreto en un año lectivo: '1° Curso A - Mañana - 2027'."""

    class Turno(models.TextChoices):
        MANANA = "M", "Mañana"
        TARDE = "T", "Tarde"
        NOCHE = "N", "Noche"

    anio_lectivo = models.ForeignKey(AnioLectivo, on_delete=models.PROTECT, related_name="secciones")
    curso = models.ForeignKey(Curso, on_delete=models.PROTECT, related_name="secciones")
    letra = models.CharField(max_length=3, default="A")
    turno = models.CharField(max_length=1, choices=Turno.choices, default=Turno.MANANA)
    cupo = models.PositiveSmallIntegerField(default=35)
    docente_guia = models.ForeignKey(
        Docente, null=True, blank=True, on_delete=models.SET_NULL, related_name="secciones_guia"
    )

    class Meta:
        ordering = ["anio_lectivo", "curso", "letra"]
        unique_together = ("anio_lectivo", "curso", "letra", "turno")
        verbose_name = "sección"
        verbose_name_plural = "secciones"

    @property
    def inscriptos(self):
        return self.matriculas.filter(estado=Matricula.Estado.ACTIVA).count()

    def __str__(self):
        return f"{self.curso} {self.letra} ({self.get_turno_display()}) {self.anio_lectivo}"


class Asignacion(models.Model):
    """Qué docente dicta qué materia en qué sección. Es la 'clase' donde se llama lista."""

    seccion = models.ForeignKey(Seccion, on_delete=models.CASCADE, related_name="asignaciones")
    materia = models.ForeignKey(Materia, on_delete=models.PROTECT)
    docente = models.ForeignKey(Docente, on_delete=models.PROTECT, related_name="asignaciones")
    horas_semanales = models.PositiveSmallIntegerField(default=2)

    class Meta:
        unique_together = ("seccion", "materia")
        verbose_name = "asignación docente"
        verbose_name_plural = "asignaciones docentes"

    def __str__(self):
        return f"{self.materia} - {self.seccion} - {self.docente}"


class Matricula(models.Model):
    class Estado(models.TextChoices):
        ACTIVA = "ACTIVA", "Activa"
        RETIRADO = "RETIRADO", "Retirado"
        TRASLADADO = "TRASLADADO", "Trasladado (pase)"
        PROMOVIDO = "PROMOVIDO", "Promovido"
        REPROBADO = "REPROBADO", "No promovido"

    alumno = models.ForeignKey(Alumno, on_delete=models.PROTECT, related_name="matriculas")
    seccion = models.ForeignKey(Seccion, on_delete=models.PROTECT, related_name="matriculas")
    anio_lectivo = models.ForeignKey(AnioLectivo, on_delete=models.PROTECT, editable=False)
    numero_lista = models.PositiveSmallIntegerField("N° de lista", null=True, blank=True)
    fecha = models.DateField("Fecha de matriculación")
    estado = models.CharField(max_length=12, choices=Estado.choices, default=Estado.ACTIVA)
    fecha_baja = models.DateField(null=True, blank=True)
    motivo_baja = models.CharField(max_length=200, blank=True)
    institucion_procedencia = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["seccion", "numero_lista", "alumno__apellidos"]
        constraints = [
            # Un alumno tiene una sola matrícula por año lectivo.
            models.UniqueConstraint(fields=["alumno", "anio_lectivo"], name="matricula_unica_por_anio"),
        ]
        verbose_name = "matrícula"

    def clean(self):
        if not self.seccion_id:
            return
        self.anio_lectivo_id = self.seccion.anio_lectivo_id
        if self.alumno_id and Matricula.objects.filter(
            alumno_id=self.alumno_id, anio_lectivo_id=self.anio_lectivo_id
        ).exclude(pk=self.pk).exists():
            raise ValidationError("El alumno ya está matriculado en este año lectivo.")
        nueva = self.pk is None
        if nueva and self.estado == self.Estado.ACTIVA and self.seccion.inscriptos >= self.seccion.cupo:
            raise ValidationError(f"La sección {self.seccion} ya completó su cupo ({self.seccion.cupo}).")

    def save(self, *args, **kwargs):
        self.anio_lectivo_id = self.seccion.anio_lectivo_id
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.alumno} - {self.seccion}"
