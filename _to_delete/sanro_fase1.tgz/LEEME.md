# Sistema San Roque — Backend (Fase 1)

## Puesta en marcha (Windows, dentro de `servidor`)
```
venv\Scripts\activate
copy .env.ejemplo .env
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
Admin: http://127.0.0.1:8000/admin/ · API: http://127.0.0.1:8000/api/

## Endpoints principales
| Uso | Método y URL |
|---|---|
| Login (devuelve access/refresh) | POST `/api/auth/token/` {username, password} |
| Renovar token | POST `/api/auth/refresh/` {refresh} |
| Usuario logueado y su rol | GET `/api/yo/` |
| Clases del docente (año activo) | GET `/api/asignaciones/mias/` |
| Lista de alumnos de una clase | GET `/api/asignaciones/{id}/lista/` |
| Guardar lista (crea o actualiza) | POST `/api/sesiones/` |
| % asistencia de una sección | GET `/api/secciones/{id}/asistencia/` |
| % asistencia de un alumno | GET `/api/alumnos/{id}/asistencia/` |
| Tablero del día (director) | GET `/api/reportes/resumen-dia/?fecha=AAAA-MM-DD` |

CRUD: usuarios, alumnos, tutores, alumnos-tutores, documentos-alumno, docentes, instituciones,
anios-lectivos, etapas, dias-no-lectivos, niveles, especialidades, cursos, materias, plan-materias,
secciones, asignaciones, matriculas, sesiones, justificaciones, permisos-docentes.
Filtros por parámetro, ej.: `/api/matriculas/?seccion=3`, `/api/alumnos/?search=Benítez`.

### Guardar lista (POST /api/sesiones/)
```json
{
  "uuid": "generado-en-el-celular (opcional)",
  "asignacion": 5, "fecha": "2027-03-02", "hora_inicio": "07:00", "tema": "Hojas de cálculo",
  "registros": [{"matricula": 12, "estado": "P"}, {"matricula": 13, "estado": "A"}]
}
```
Estados: P presente, A ausente, T tardanza, J justificado. Reenviar la misma clase (mismo uuid
o misma asignación y fecha) la actualiza, no la duplica: sirve para sincronizar sin internet.

## Roles
- DIRECTOR, COORDINADOR, SECRETARIA: administran todo.
- DOCENTE: consulta datos y solo llama lista en sus propias clases.
- TUTOR: reservado para el portal de padres (fase 3).

## Pruebas
`python manage.py test`
