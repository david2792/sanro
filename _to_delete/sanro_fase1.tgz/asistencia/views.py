from datetime import date

from django.db.models import Count, Q
from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response

from academico.models import Asignacion
from academico.views import FiltroParamsMixin
from personas.models import Docente
from personas.permisos import EsGestion, EsPersonal
from .models import Justificacion, PermisoDocente, SesionClase
from .serializers import JustificacionSerializer, PermisoDocenteSerializer, SesionClaseSerializer


class SesionClaseViewSet(FiltroParamsMixin, viewsets.ModelViewSet):
    """
    POST /api/sesiones/  -> guarda (o actualiza) la lista de una clase.
    GET  /api/sesiones/?asignacion=5&fecha=2027-03-02
    """

    serializer_class = SesionClaseSerializer
    permission_classes = [EsPersonal]
    filtros = ["asignacion", "fecha", "docente", "asignacion__seccion"]

    def get_queryset(self):
        qs = SesionClase.objects.select_related(
            "asignacion__materia", "asignacion__seccion__curso", "docente"
        ).prefetch_related("registros__matricula__alumno")
        user = self.request.user
        if not user.es_gestion:
            qs = qs.filter(asignacion__docente__usuario=user)
        return qs


class JustificacionViewSet(FiltroParamsMixin, viewsets.ModelViewSet):
    queryset = Justificacion.objects.select_related("matricula__alumno")
    serializer_class = JustificacionSerializer
    permission_classes = [EsGestion]
    filtros = ["matricula", "matricula__alumno"]

    def perform_create(self, serializer):
        serializer.save(registrado_por=self.request.user)


class PermisoDocenteViewSet(FiltroParamsMixin, viewsets.ModelViewSet):
    queryset = PermisoDocente.objects.select_related("docente")
    serializer_class = PermisoDocenteSerializer
    permission_classes = [EsGestion]
    filtros = ["docente"]


@api_view(["GET"])
@permission_classes([EsGestion])
def resumen_dia(request):
    """
    Tablero del día para el director: ?fecha=AAAA-MM-DD (por defecto hoy).
    - Clases con lista llamada y cuántos ausentes hubo en cada una.
    - Docentes que registraron clase, docentes con permiso y docentes sin registro.
    """
    fecha = request.query_params.get("fecha") or date.today().isoformat()

    sesiones = (
        SesionClase.objects.filter(fecha=fecha)
        .select_related("asignacion__materia", "asignacion__seccion__curso", "docente")
        .annotate(
            total=Count("registros"),
            ausentes=Count("registros", filter=Q(registros__estado="A")),
            tardanzas=Count("registros", filter=Q(registros__estado="T")),
        )
    )
    clases = [{
        "sesion": s.id,
        "seccion": str(s.asignacion.seccion),
        "materia": s.asignacion.materia.nombre,
        "docente": str(s.docente),
        "hora_inicio": s.hora_inicio,
        "alumnos": s.total,
        "ausentes": s.ausentes,
        "tardanzas": s.tardanzas,
    } for s in sesiones]

    con_clase = set(sesiones.values_list("docente_id", flat=True))
    con_permiso = set(PermisoDocente.objects.filter(
        fecha_desde__lte=fecha, fecha_hasta__gte=fecha).values_list("docente_id", flat=True))
    activos = Docente.objects.filter(
        activo=True, asignaciones__seccion__anio_lectivo__activo=True).distinct()

    def nombres(ids):
        return [str(d) for d in activos if d.id in ids]

    return Response({
        "fecha": fecha,
        "clases": clases,
        "docentes_con_clase": nombres(con_clase),
        "docentes_con_permiso": nombres(con_permiso),
        # Sin el módulo de horarios (fase 4) no se sabe qué día le toca a cada uno;
        # esta lista muestra a quienes no registraron ninguna clase en la fecha.
        "docentes_sin_registro": nombres({d.id for d in activos} - con_clase - con_permiso),
    })
