from rest_framework import serializers

from .models import Alumno, AlumnoTutor, Docente, DocumentoAlumno, Tutor, Usuario


class UsuarioSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False)
    docente_id = serializers.SerializerMethodField()

    class Meta:
        model = Usuario
        fields = ["id", "username", "first_name", "last_name", "email", "rol", "ci",
                  "telefono", "is_active", "password", "docente_id"]

    def get_docente_id(self, obj):
        return getattr(getattr(obj, "docente", None), "id", None)

    def create(self, data):
        password = data.pop("password", None)
        user = Usuario(**data)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save()
        return user

    def update(self, user, data):
        password = data.pop("password", None)
        for k, v in data.items():
            setattr(user, k, v)
        if password:
            user.set_password(password)
        user.save()
        return user


class AlumnoTutorSerializer(serializers.ModelSerializer):
    tutor_nombre = serializers.CharField(source="tutor.__str__", read_only=True)
    tutor_telefono = serializers.CharField(source="tutor.telefono", read_only=True)

    class Meta:
        model = AlumnoTutor
        fields = ["id", "alumno", "tutor", "tutor_nombre", "tutor_telefono", "parentesco", "es_principal"]


class DocumentoAlumnoSerializer(serializers.ModelSerializer):
    class Meta:
        model = DocumentoAlumno
        fields = ["id", "alumno", "tipo", "archivo", "subido"]


class AlumnoSerializer(serializers.ModelSerializer):
    tutores = AlumnoTutorSerializer(source="alumnotutor_set", many=True, read_only=True)
    documentos = DocumentoAlumnoSerializer(many=True, read_only=True)
    seccion_actual = serializers.SerializerMethodField()

    class Meta:
        model = Alumno
        fields = "__all__"

    def get_seccion_actual(self, obj):
        m = obj.matriculas.filter(estado="ACTIVA", anio_lectivo__activo=True).select_related("seccion").first()
        return {"matricula_id": m.id, "seccion_id": m.seccion_id, "seccion": str(m.seccion)} if m else None


class TutorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tutor
        exclude = ["alumnos"]


class DocenteSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source="usuario.username", read_only=True)

    class Meta:
        model = Docente
        fields = "__all__"
