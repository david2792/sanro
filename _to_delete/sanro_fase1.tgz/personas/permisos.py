from rest_framework.permissions import SAFE_METHODS, BasePermission


class EsGestion(BasePermission):
    """Director/a, coordinación, secretaría o superusuario."""

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.es_gestion)


class EsPersonal(BasePermission):
    """Cualquier funcionario (todos menos padres/tutores)."""

    def has_permission(self, request, view):
        u = request.user
        return bool(u and u.is_authenticated and (u.is_superuser or u.rol != u.Rol.TUTOR))


class GestionEscribePersonalLee(BasePermission):
    """El personal consulta; solo gestión crea, modifica o borra."""

    def has_permission(self, request, view):
        if not EsPersonal().has_permission(request, view):
            return False
        return request.method in SAFE_METHODS or request.user.es_gestion
