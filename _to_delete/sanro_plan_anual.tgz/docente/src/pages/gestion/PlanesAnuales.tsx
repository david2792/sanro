import { useQuery, useQueryClient } from '@tanstack/react-query'
import { ChevronRight, FileText, Search } from 'lucide-react'
import { useMemo, useState } from 'react'
import { usePaginacion } from '../../components/Crud'
import { Boton, Campo, Cargando, Encabezado, ErrorCaja, Etiqueta, Hoja, Input, Segmentado, Textarea, useAviso, Vacio } from '../../components/ui'
import { api, lista } from '../../lib/api'
import { fechaCorta } from '../../lib/utils'
import { ESTADO_PLAN, fechaHora } from '../docente/PlanAnual'

type Filtro = 'TODOS' | 'PENDIENTES' | 'ENVIADO' | 'OBSERVADO' | 'APROBADO'

/** Dirección y coordinación: seguimiento y revisión del plan anual de cada materia. */
export default function PlanesAnuales() {
  const planes = useQuery({ queryKey: ['planes-anuales'], queryFn: () => api('/planes-anuales/') })
  const [filtro, setFiltro] = useState<Filtro>('ENVIADO')
  const [q, setQ] = useState('')
  const [abierto, setAbierto] = useState<any | null>(null)

  const todos: any[] = planes.data ?? []
  const cuenta = (f: (p: any) => boolean) => todos.filter(f).length
  const pendiente = (p: any) => p.estado === 'SIN_CARGAR' || p.estado === 'BORRADOR'
  const filtrados = useMemo(() => {
    const t = q.toLowerCase()
    return todos.filter((p) =>
      (filtro === 'TODOS' || (filtro === 'PENDIENTES' ? pendiente(p) : p.estado === filtro)) &&
      (!t || `${p.materia} ${p.seccion} ${p.docente}`.toLowerCase().includes(t)))
  }, [todos, filtro, q])
  const { visibles, paginador } = usePaginacion(filtrados, 30)

  return (
    <div>
      <Encabezado titulo="Planes anuales" detalle="El plan anual de cada materia: quién lo entregó y qué falta revisar." />
      {planes.isLoading && <Cargando />}
      <ErrorCaja error={planes.error} />

      {planes.data && (
        <>
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <Segmentado valor={filtro} onChange={setFiltro} opciones={[
              { valor: 'ENVIADO', label: `Por revisar ${cuenta((p) => p.estado === 'ENVIADO')}` },
              { valor: 'PENDIENTES', label: `Sin entregar ${cuenta(pendiente)}` },
              { valor: 'OBSERVADO', label: `Devueltos ${cuenta((p) => p.estado === 'OBSERVADO')}` },
              { valor: 'APROBADO', label: `Aprobados ${cuenta((p) => p.estado === 'APROBADO')}` },
              { valor: 'TODOS', label: 'Todos' },
            ]} />
            <div className="relative min-w-52 flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-5 -translate-y-1/2 text-grafito-500" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar docente, materia o sección…" className="pl-10" />
            </div>
          </div>

          {!filtrados.length ? (
            <Vacio titulo={filtro === 'ENVIADO' ? 'No hay planes esperando revisión' : 'Nada en esta lista'} />
          ) : (
            <ul className="divide-y divide-grafito-100 overflow-hidden rounded-xl border border-grafito-200 bg-white">
              {visibles.map((p) => {
                const e = ESTADO_PLAN[p.estado]
                return (
                  <li key={p.asignacion}>
                    <button onClick={() => setAbierto(p)} className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-tinta-50/60 active:bg-tinta-50">
                      <div className="min-w-0 flex-1">
                        <p className="font-bold">{p.materia} <span className="font-normal text-grafito-500">· {p.docente}</span></p>
                        <p className="truncate text-sm text-grafito-500">{p.seccion}</p>
                        <p className="text-sm text-grafito-500">
                          {[p.archivo && 'PDF subido', p.unidades && `${p.unidades} ${p.unidades === 1 ? 'unidad cargada' : 'unidades cargadas'}`].filter(Boolean).join(' · ') || 'Nada cargado'}
                          {p.enviado && ` · enviado ${fechaCorta(p.enviado)}`}
                        </p>
                      </div>
                      <Etiqueta tono={e.tono}>{e.texto}</Etiqueta>
                      <ChevronRight className="size-5 shrink-0 text-grafito-300" />
                    </button>
                  </li>
                )
              })}
            </ul>
          )}
          {paginador}
        </>
      )}

      {abierto && <Revision plan={abierto} onCerrar={() => setAbierto(null)} />}
    </div>
  )
}

function Revision({ plan, onCerrar }: { plan: any; onCerrar: () => void }) {
  const qc = useQueryClient()
  const avisar = useAviso()
  const [obs, setObs] = useState(plan.estado === 'OBSERVADO' ? plan.observaciones : '')
  const [guardando, setGuardando] = useState('')
  const unidades = useQuery({ queryKey: ['unidades', plan.asignacion], queryFn: () => lista(`/unidades/?asignacion=${plan.asignacion}`) })

  const decidir = async (decision: 'APROBADO' | 'OBSERVADO') => {
    setGuardando(decision)
    try {
      await api(`/plan-anual/${plan.asignacion}/revisar/`, { method: 'POST', body: { decision, observaciones: obs } })
      await qc.invalidateQueries({ queryKey: ['planes-anuales'] })
      avisar(decision === 'APROBADO' ? 'Plan anual aprobado' : 'Plan anual devuelto al docente')
      onCerrar()
    } catch (e) {
      avisar(e instanceof Error ? e.message : 'No se pudo guardar.', 'error')
    } finally {
      setGuardando('')
    }
  }

  const e = ESTADO_PLAN[plan.estado]
  const nada = !plan.archivo && !plan.unidades
  return (
    <Hoja abierta titulo={`Plan anual · ${plan.materia}`} onCerrar={onCerrar}
      pie={nada ? undefined : <>
        <Boton variante="secundario" className="flex-1 text-ausente" onClick={() => decidir('OBSERVADO')} cargando={guardando === 'OBSERVADO'}>Devolver</Boton>
        <Boton className="flex-1" onClick={() => decidir('APROBADO')} cargando={guardando === 'APROBADO'}>Aprobar</Boton>
      </>}>
      <div className="space-y-4">
        <div>
          <p className="font-bold">{plan.docente}</p>
          <p className="text-sm text-grafito-500">{plan.seccion}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Etiqueta tono={e.tono}>{e.texto}</Etiqueta>
            {plan.enviado && <span className="text-sm text-grafito-500">Enviado {fechaHora(plan.enviado)}</span>}
          </div>
          {plan.revisado && <p className="mt-1 text-sm text-grafito-500">Última revisión: {plan.revisado_por}, {fechaHora(plan.revisado)}</p>}
        </div>

        {nada && <p className="rounded-lg bg-grafito-100 px-4 py-3 text-grafito-600">El docente todavía no subió el PDF ni cargó unidades.</p>}

        {plan.archivo && (
          <a href={plan.archivo} target="_blank" rel="noreferrer"
            className="flex items-center gap-3 rounded-xl border border-grafito-200 px-4 py-3 font-bold text-tinta-700 hover:bg-tinta-50">
            <FileText className="size-6" /> Abrir el PDF del plan anual
          </a>
        )}

        {plan.unidades > 0 && (
          <div>
            <p className="mb-2 text-sm font-bold text-grafito-600">Unidades cargadas en el sistema ({plan.unidades_completas} de {plan.unidades} completas)</p>
            {unidades.isLoading ? <Cargando /> : (
              <ol className="space-y-2">
                {unidades.data?.map((u: any) => (
                  <li key={u.id} className="rounded-lg border border-grafito-200 px-3 py-2 text-[15px]">
                    <p className="font-bold">U{u.numero}. {u.titulo}</p>
                    <p className="text-sm text-grafito-500">
                      {u.fecha_inicio ? `${fechaCorta(u.fecha_inicio)} al ${fechaCorta(u.fecha_fin)}` : 'Sin fechas'} ·{' '}
                      {u.capacidades.length} capacidades · {u.capacidades.reduce((s: number, c: any) => s + c.indicadores.length, 0)} indicadores
                    </p>
                    {u.contenidos && <p className="mt-1 line-clamp-2 text-grafito-600"><b>Contenidos:</b> {u.contenidos}</p>}
                    {u.evaluacion && <p className="line-clamp-2 text-grafito-600"><b>Evaluación:</b> {u.evaluacion}</p>}
                    {!u.contenidos && !u.evaluacion && <p className="text-sm text-tarde">Faltan contenidos y evaluación.</p>}
                  </li>
                ))}
              </ol>
            )}
          </div>
        )}

        {!nada && (
          <Campo label="Observaciones para el docente" ayuda="Obligatorias si lo devolvés. Si lo aprobás, son opcionales.">
            <Textarea rows={3} value={obs} onChange={(ev) => setObs(ev.target.value)} />
          </Campo>
        )}
      </div>
    </Hoja>
  )
}
