import { useQuery, useQueryClient } from '@tanstack/react-query'
import { CheckCircle2, FileText, MessageSquareWarning, Send, Trash2, Upload } from 'lucide-react'
import { useRef, useState } from 'react'
import { Boton, Confirmar, Etiqueta, useAviso } from '../../components/ui'
import { api } from '../../lib/api'
import { cn } from '../../lib/utils'

export const ESTADO_PLAN: Record<string, { texto: string; tono: 'gris' | 'verde' | 'rojo' | 'ambar' | 'azul' }> = {
  SIN_CARGAR: { texto: 'Sin cargar', tono: 'gris' },
  BORRADOR: { texto: 'En borrador', tono: 'ambar' },
  ENVIADO: { texto: 'Enviado a coordinación', tono: 'azul' },
  APROBADO: { texto: 'Aprobado', tono: 'verde' },
  OBSERVADO: { texto: 'Devuelto con observaciones', tono: 'rojo' },
}

export function fechaHora(iso?: string | null) {
  if (!iso) return ''
  const d = new Date(iso)
  return `${d.toLocaleDateString('es-PY')} ${d.toLocaleTimeString('es-PY', { hour: '2-digit', minute: '2-digit' })}`
}

/**
 * Estado del plan anual de la materia, para el docente:
 * subir el PDF o cargarlo unidad por unidad (debajo), y enviarlo a coordinación.
 */
export default function PlanAnualDocente({ asignacion }: { asignacion: number }) {
  const qc = useQueryClient()
  const avisar = useAviso()
  const input = useRef<HTMLInputElement>(null)
  const [ocupado, setOcupado] = useState<'' | 'subir' | 'enviar' | 'quitar'>('')
  const [quitar, setQuitar] = useState(false)
  const plan = useQuery({ queryKey: ['plan-anual', asignacion], queryFn: () => api(`/plan-anual/${asignacion}/`) })
  const p = plan.data

  const ejecutar = async (accion: 'subir' | 'enviar' | 'quitar', body?: FormData) => {
    setOcupado(accion)
    try {
      const ruta = { subir: 'archivo', enviar: 'enviar', quitar: 'quitar-archivo' }[accion]
      const r = await api(`/plan-anual/${asignacion}/${ruta}/`, { method: 'POST', body })
      qc.setQueryData(['plan-anual', asignacion], r)
      avisar({ subir: 'PDF del plan anual guardado', enviar: 'Plan anual enviado a coordinación', quitar: 'PDF quitado' }[accion])
    } catch (e) {
      avisar(e instanceof Error ? e.message : 'No se pudo completar.', 'error')
    } finally {
      setOcupado('')
      if (input.current) input.current.value = ''
    }
  }

  const subir = (f?: File) => {
    if (!f) return
    const fd = new FormData()
    fd.append('archivo', f)
    void ejecutar('subir', fd)
  }

  if (!p) return null
  const estado = ESTADO_PLAN[p.estado] ?? ESTADO_PLAN.SIN_CARGAR
  const puedeEnviar = (p.archivo || p.unidades > 0) && p.estado !== 'ENVIADO' && p.estado !== 'APROBADO'

  return (
    <section className={cn('mb-5 rounded-xl border bg-white p-4',
      p.estado === 'OBSERVADO' ? 'border-ausente' : p.estado === 'APROBADO' ? 'border-presente' : 'border-grafito-200')}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="text-lg font-bold">Plan anual</h2>
          <p className="text-sm text-grafito-500">Subí el PDF o cargalo unidad por unidad acá abajo. Después envialo a coordinación.</p>
        </div>
        <Etiqueta tono={estado.tono}>{estado.texto}</Etiqueta>
      </div>

      {p.estado === 'OBSERVADO' && p.observaciones && (
        <div className="mt-3 rounded-lg bg-ausente-50 px-3 py-2.5 text-[15px]">
          <p className="flex items-center gap-1.5 font-bold text-ausente"><MessageSquareWarning className="size-4" /> Observaciones de coordinación</p>
          <p className="mt-0.5 whitespace-pre-line text-grafito">{p.observaciones}</p>
          <p className="mt-1 text-xs text-grafito-500">{p.revisado_por} · {fechaHora(p.revisado)}</p>
        </div>
      )}
      {p.estado === 'APROBADO' && (
        <p className="mt-3 flex items-center gap-1.5 text-sm text-presente">
          <CheckCircle2 className="size-4" /> Aprobado por {p.revisado_por} el {fechaHora(p.revisado)}
          {p.observaciones && <span className="text-grafito-600"> · {p.observaciones}</span>}
        </p>
      )}
      {p.estado === 'ENVIADO' && (
        <p className="mt-3 text-sm text-justificado">Enviado el {fechaHora(p.enviado)}. Coordinación lo va a revisar.</p>
      )}

      <div className="mt-4 flex flex-wrap items-center gap-2">
        {p.archivo ? (
          <>
            <a href={p.archivo} target="_blank" rel="noreferrer"
              className="inline-flex h-11 items-center gap-2 rounded-control bg-tinta-50 px-4 font-bold text-tinta-700 hover:bg-tinta-100">
              <FileText className="size-5" /> Ver PDF
            </a>
            <Boton variante="secundario" onClick={() => input.current?.click()} cargando={ocupado === 'subir'}>
              <Upload className="size-4" /> Reemplazar
            </Boton>
            <Boton variante="fantasma" className="text-ausente" onClick={() => setQuitar(true)} aria-label="Quitar PDF">
              <Trash2 className="size-4" />
            </Boton>
          </>
        ) : (
          <Boton variante="secundario" onClick={() => input.current?.click()} cargando={ocupado === 'subir'}>
            <Upload className="size-4" /> Subir PDF
          </Boton>
        )}
        <input ref={input} type="file" accept="application/pdf,.pdf" className="hidden" onChange={(e) => subir(e.target.files?.[0])} />
        <Boton className="ml-auto" onClick={() => void ejecutar('enviar')} disabled={!puedeEnviar} cargando={ocupado === 'enviar'}>
          <Send className="size-4" /> {p.estado === 'OBSERVADO' ? 'Reenviar a coordinación' : 'Enviar a coordinación'}
        </Boton>
      </div>
      <p className="mt-2 text-sm text-grafito-500">
        {p.unidades
          ? `${p.unidades} ${p.unidades === 1 ? 'unidad cargada' : 'unidades cargadas'} · ${p.unidades_completas} con fechas, contenidos y evaluación`
          : 'Sin unidades cargadas en el sistema.'}
      </p>
      <Confirmar abierta={quitar} titulo="Quitar el PDF" texto="Se borra el archivo subido del plan anual." accion="Quitar"
        onCerrar={() => setQuitar(false)} onConfirmar={() => { setQuitar(false); void ejecutar('quitar') }} />
    </section>
  )
}
