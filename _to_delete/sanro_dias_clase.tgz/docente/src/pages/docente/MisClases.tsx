import { useQuery } from '@tanstack/react-query'
import { Check, ChevronRight } from 'lucide-react'
import { Link } from 'react-router'
import { Cargando, ErrorCaja, Vacio } from '../../components/ui'
import { api, lista } from '../../lib/api'
import { useAuth } from '../../lib/auth'
import { usePendientes } from '../../lib/offline'
import { cn, diasTexto, fechaLarga, hoyISO, tieneClase } from '../../lib/utils'

export default function MisClases() {
  const { usuario } = useAuth()
  const hoy = hoyISO()
  const clases = useQuery({ queryKey: ['mias'], queryFn: () => api('/asignaciones/mias/', { cache: true }) })
  const hechas = useQuery({
    queryKey: ['sesiones-hoy', hoy],
    queryFn: () => lista(`/sesiones/?fecha=${hoy}`),
    retry: false,
  })
  const pendientes = usePendientes()
  const listaHecha = (asig: number) =>
    hechas.data?.some((s: any) => s.asignacion === asig) || pendientes.some((p) => p.body.asignacion === asig && p.body.fecha === hoy)

  // Hoy: las materias que tienen clase hoy (o ya tienen lista hoy). El resto, aparte.
  const todas: any[] = clases.data ?? []
  const deHoy = todas.filter((c) => tieneClase(c.dias_clase, hoy) || listaHecha(c.id))
  const otras = todas.filter((c) => !deHoy.includes(c))
  const sinDias = todas.some((c) => !c.dias_clase?.length)

  return (
    <div>
      <p className="text-grafito-500 first-letter:uppercase">{fechaLarga(hoy)}</p>
      <h1 className="mb-6 text-2xl font-bold">Hola, {usuario?.first_name || usuario?.username}</h1>

      {clases.isLoading && <Cargando />}
      <ErrorCaja error={clases.error} />
      {clases.data && !clases.data.length && (
        <Vacio titulo="No tenés clases asignadas este año" texto="Pedí a coordinación que te asigne tus materias y secciones." />
      )}

      {todas.length > 0 && (
        <section className="mb-8">
          <h2 className="mb-2 text-lg font-bold">Clases de hoy</h2>
          {deHoy.length ? (
            <ListaClases clases={deHoy} listaHecha={listaHecha} conEstado />
          ) : (
            <p className="rounded-xl border border-dashed border-grafito-300 px-4 py-6 text-center text-grafito-500">
              Hoy no tenés clases según tus días de clase.
            </p>
          )}
        </section>
      )}

      {otras.length > 0 && (
        <section>
          <h2 className="mb-2 text-lg font-bold">Otras materias</h2>
          <ListaClases clases={otras} listaHecha={listaHecha} />
        </section>
      )}

      {sinDias && (
        <p className="mt-6 text-sm text-grafito-500">
          Las materias sin días de clase cargados aparecen todos los días. Entrá a la materia y tocá "Días de clase" para cargarlos.
        </p>
      )}
    </div>
  )
}

function ListaClases({ clases, listaHecha, conEstado }: { clases: any[]; listaHecha: (id: number) => boolean; conEstado?: boolean }) {
  return (
    <ul className="divide-y divide-grafito-100 overflow-hidden rounded-xl border border-grafito-200 bg-white">
      {clases.map((c) => {
        const hecha = listaHecha(c.id)
        const dias = diasTexto(c.dias_clase)
        return (
          <li key={c.id}>
            <Link to={`/clases/${c.id}`} className="flex items-center gap-4 px-4 py-4 active:bg-tinta-50">
              <span className={cn('grid size-11 shrink-0 place-items-center rounded-full text-lg font-bold',
                hecha ? 'bg-presente text-white' : conEstado ? 'bg-tinta-100 text-tinta-700' : 'bg-grafito-100 text-grafito-500')}>
                {hecha ? <Check className="size-6" /> : c.materia_nombre[0]}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-lg font-bold leading-tight">{c.materia_nombre}</p>
                <p className="truncate text-sm text-grafito-500">{c.seccion_descripcion}</p>
                <p className={cn('text-sm', conEstado && !hecha ? 'font-bold text-tarde' : 'text-grafito-500')}>
                  {conEstado ? (hecha ? 'Lista de hoy guardada' : 'Falta llamar lista') : dias ? `Clases los ${dias}` : 'Sin días de clase cargados'}
                </p>
              </div>
              <ChevronRight className="size-5 text-grafito-300" />
            </Link>
          </li>
        )
      })}
    </ul>
  )
}
