export function cn(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(' ')
}

/** Fecha local en formato AAAA-MM-DD (no UTC). */
export function hoyISO(d = new Date()) {
  const z = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`
}

const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado']
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']

export function fechaLarga(iso: string) {
  const [a, m, d] = iso.split('-').map(Number)
  const f = new Date(a, m - 1, d)
  return `${DIAS[f.getDay()]} ${d} de ${MESES[m - 1]}`
}

export function fechaCorta(iso?: string | null) {
  if (!iso) return ''
  const [a, m, d] = iso.slice(0, 10).split('-')
  return `${d}/${m}/${a}`
}

/** UUID v4 que funciona también por http en la red local (sin crypto.randomUUID). */
export function uuid() {
  const b = crypto.getRandomValues(new Uint8Array(16))
  b[6] = (b[6] & 0x0f) | 0x40
  b[8] = (b[8] & 0x3f) | 0x80
  const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('')
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`
}

/**
 * 200000 -> "200.000". Siempre con punto de miles, también en 4 cifras (1.500):
 * Intl en español no agrupa los números de 4 cifras.
 */
export function miles(n: number | string | null | undefined) {
  const v = Math.round(Number(n) || 0)
  return (v < 0 ? '-' : '') + String(Math.abs(v)).replace(/\B(?=(\d{3})+(?!\d))/g, '.')
}

/** 25000 -> "Gs. 25.000" */
export function guaranies(n: number | string | null | undefined) {
  return `Gs. ${miles(n)}`
}

export const MES_CORTO = ['', 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic']

/** Descarga una tabla como CSV que Excel abre bien en español (separador ; y acentos). */
export function descargarCSV(nombre: string, filas: (string | number | null | undefined)[][]) {
  const celda = (v: string | number | null | undefined) => {
    const t = v == null ? '' : String(v)
    return /[;"\n]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t
  }
  const texto = '﻿' + filas.map((f) => f.map(celda).join(';')).join('\r\n')
  const url = URL.createObjectURL(new Blob([texto], { type: 'text/csv;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url
  a.download = `${nombre}.csv`
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

export function iniciales(nombre: string) {
  return nombre
    .replace(',', '')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('')
}

/** Días de clase: 1 = lunes … 6 = sábado (como en el backend). */
export const DIAS_SEMANA = [
  { n: 1, corto: 'Lun', largo: 'lunes' },
  { n: 2, corto: 'Mar', largo: 'martes' },
  { n: 3, corto: 'Mié', largo: 'miércoles' },
  { n: 4, corto: 'Jue', largo: 'jueves' },
  { n: 5, corto: 'Vie', largo: 'viernes' },
  { n: 6, corto: 'Sáb', largo: 'sábado' },
]

/** [2, 4] -> "martes y jueves" */
export function diasTexto(dias?: number[] | null) {
  const nombres = DIAS_SEMANA.filter((d) => dias?.includes(d.n)).map((d) => d.largo)
  if (!nombres.length) return ''
  return nombres.length === 1 ? nombres[0] : `${nombres.slice(0, -1).join(', ')} y ${nombres[nombres.length - 1]}`
}

/** Día de la semana de una fecha AAAA-MM-DD, en la misma numeración (1 = lunes, 7 = domingo). */
export function diaSemana(iso: string) {
  const [a, m, d] = iso.split('-').map(Number)
  return ((new Date(a, m - 1, d).getDay() + 6) % 7) + 1
}

/** Si la materia tiene clase ese día. Sin días cargados se considera que sí. */
export function tieneClase(dias: number[] | null | undefined, iso: string) {
  return !dias?.length || dias.includes(diaSemana(iso))
}
