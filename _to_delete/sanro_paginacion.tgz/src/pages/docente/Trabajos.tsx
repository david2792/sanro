import { useQuery, useQueryClient } from '@tanstack/react-query'
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react'
import { useState } from 'react'
import { Boton, Campo, Cargando, Casilla, Confirmar, ErrorCaja, Hoja, Input, Segmentado, Select, Textarea, useAviso, Vacio } from '../../components/ui'
import { usePaginacion } from '../../components/Crud'
import { api, lista } from '../../lib/api'
import { cn, fechaCorta, hoyISO } from '../../lib/utils'
import { useEtapas } from './Clase'

export const TIPOS_TRABAJO = [
  { valor: 'PRACTICO', label: 'Trabajo práctico' },
  { valor: 'PRUEBA', label: 'Prueba escrita' },
  { valor: 'INVESTIGACION', label: 'Trabajo de investigación' },
  { valor: 'EXPOSICION', label: 'Exposición oral' },
  { valor: 'CARPETA', label: 'Carpeta / cuaderno' },
  { valor: 'PROYECTO', label: 'Proyecto' },
  { valor: 'LISTA_COTEJO', label: 'Lista de cotejo' },
  { valor: 'RUBRICA', label: 'Rúbrica' },
  { valor: 'OTRO', label: 'Otro' },
]
const tipoTexto = (t: string) => TIPOS_TRABAJO.find((x) => x.valor === t)?.label ?? t
const num = (v: any) => (v == null ? '' : String(Number(v)))

export default function Trabajos({ asignacion, seccion }: { asignacion: number; seccion: number }) {
  const etapas = useEtapas(seccion)
  const [etapa, setEtapa] = useState<number | null>(null)
  const [vista, setVista] = useState<'trabajos' | 'planilla'>('trabajos')
  const [abierto, setAbierto] = useState<any | null>(null)
  const [editar, setEditar] = useState<any | null | undefined>(undefined)
  const etapaId = etapa ?? etapas.data?.actual?.id ?? null

  const trabajos = useQuery({
    queryKey: ['instrumentos', asignacion, etapaId],
    enabled: etapaId != null,
    queryFn: () => lista(`/instrumentos/?asignacion=${asignacion}&etapa=${etapaId}`, true),
  })
  const { visibles: trabajosVisibles, paginador } = usePaginacion(trabajos.data ?? [], 15)

  if (etapas.isLoading) return <Cargando />
  if (!etapas.data?.etapas.length) return <Vacio titulo="El año lectivo no tiene etapas" texto="Coordinación debe cargar las etapas para poder crear trabajos." />
  if (abierto) return <Puntajes instrumento={abierto} etapas={etapas.data.etapas} onVolver={() => setAbierto(null)} />

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Select value={etapaId ?? ''} onChange={(e) => setEtapa(Number(e.target.value))} className="w-auto">
          {etapas.data.etapas.map((e: any) => <option key={e.id} value={e.id}>{e.numero}ª {e.nombre}</option>)}
        </Select>
        <Segmentado valor={vista} onChange={setVista} opciones={[{ valor: 'trabajos', label: 'Trabajos' }, { valor: 'planilla', label: 'Planilla' }]} />
        <Boton className="ml-auto" onClick={() => setEditar(null)}><Plus className="size-5" /> Trabajo</Boton>
      </div>

      {vista === 'planilla' ? <Planilla asignacion={asignacion} etapa={etapaId!} /> : (
        <>
          {trabajos.isLoading && <Cargando />}
          {trabajos.data && !trabajos.data.length && (
            <Vacio titulo="Sin trabajos en esta etapa" texto="Creá un trabajo con su puntaje total y después cargá lo que logró cada alumno." />
          )}
          <ul className="space-y-3">
            {trabajosVisibles.map((t: any) => (
              <li key={t.id}>
                <button onClick={() => setAbierto(t)} className="flex w-full items-center gap-4 rounded-xl border border-grafito-200 bg-white px-4 py-3.5 text-left active:bg-tinta-50">
                  <div className="grid w-14 shrink-0 place-items-center rounded-lg bg-tinta-50 py-1.5 text-tinta-700">
                    <span className="text-xl font-bold leading-none">{num(t.puntaje_total)}</span>
                    <span className="text-xs">puntos</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-bold leading-snug">{t.titulo}</p>
                    <p className="text-sm text-grafito-500">{tipoTexto(t.tipo)} · {fechaCorta(t.fecha)}</p>
                    <p className={cn('text-sm font-bold', t.evaluados ? 'text-presente' : 'text-tarde')}>
                      {t.evaluados ? `${t.evaluados} alumnos con puntaje` : 'Sin puntajes cargados'}
                    </p>
                  </div>
                  <ChevronRight className="size-5 text-grafito-300" />
                </button>
              </li>
            ))}
          </ul>
          {paginador}
        </>
      )}

      {editar !== undefined && (
        <FormTrabajo asignacion={asignacion} etapas={etapas.data.etapas} etapa={etapaId} registro={editar} onCerrar={() => setEditar(undefined)} />
      )}
    </div>
  )
}

function FormTrabajo({ asignacion, etapas, etapa, registro, onCerrar, onEliminado }: {
  asignacion: number; etapas: any[]; etapa: number | null; registro: any | null; onCerrar: () => void; onEliminado?: () => void
}) {
  const qc = useQueryClient()
  const avisar = useAviso()
  const unidades = useQuery({ queryKey: ['unidades', asignacion], queryFn: () => lista(`/unidades/?asignacion=${asignacion}`, true) })
  const [v, setV] = useState<any>(registro ? { ...registro, puntaje_total: num(registro.puntaje_total) } :
    { tipo: 'PRACTICO', titulo: '', descripcion: '', fecha: hoyISO(), puntaje_total: '', etapa, indicadores: [] })
  const [guardando, setGuardando] = useState(false)
  const [error, setError] = useState('')
  const [borrar, setBorrar] = useState(false)

  const guardar = async (e: React.FormEvent) => {
    e.preventDefault()
    setGuardando(true)
    setError('')
    try {
      const body = { asignacion, tipo: v.tipo, titulo: v.titulo, descripcion: v.descripcion, fecha: v.fecha, puntaje_total: v.puntaje_total, etapa: v.etapa, indicadores: v.indicadores }
      await api(registro ? `/instrumentos/${registro.id}/` : '/instrumentos/', { method: registro ? 'PATCH' : 'POST', body })
      await qc.invalidateQueries({ queryKey: ['instrumentos', asignacion] })
      await qc.invalidateQueries({ queryKey: ['planilla', asignacion] })
      avisar(registro ? 'Trabajo actualizado' : 'Trabajo creado')
      onCerrar()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo guardar.')
    } finally {
      setGuardando(false)
    }
  }

  const eliminar = async () => {
    try {
      await api(`/instrumentos/${registro.id}/`, { method: 'DELETE' })
      await qc.invalidateQueries({ queryKey: ['instrumentos', asignacion] })
      avisar('Trabajo eliminado')
      onEliminado?.()
      onCerrar()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo eliminar.')
      setBorrar(false)
    }
  }

  const indicadores = (unidades.data ?? []).flatMap((u: any) => u.capacidades.flatMap((c: any) => c.indicadores.map((i: any) => ({ ...i, unidad: u }))))

  return (
    <>
      <Hoja abierta titulo={registro ? 'Editar trabajo' : 'Nuevo trabajo'} onCerrar={onCerrar}
        pie={<>
          {registro && <Boton type="button" variante="secundario" className="text-ausente" onClick={() => setBorrar(true)}>Eliminar</Boton>}
          <Boton type="submit" form="form-trabajo" className="flex-1" cargando={guardando}>Guardar</Boton>
        </>}>
        <form id="form-trabajo" onSubmit={guardar} className="grid grid-cols-2 gap-x-3 gap-y-4">
          <Campo label="Título" className="col-span-2"><Input value={v.titulo} onChange={(e) => setV({ ...v, titulo: e.target.value })} required placeholder="Ej.: Trabajo práctico 1" /></Campo>
          <Campo label="Tipo" className="col-span-2">
            <Select value={v.tipo} onChange={(e) => setV({ ...v, tipo: e.target.value })}>
              {TIPOS_TRABAJO.map((t) => <option key={t.valor} value={t.valor}>{t.label}</option>)}
            </Select>
          </Campo>
          <Campo label="Puntaje total"><Input type="number" inputMode="decimal" step="0.5" min="0.5" value={v.puntaje_total} onChange={(e) => setV({ ...v, puntaje_total: e.target.value })} required /></Campo>
          <Campo label="Fecha"><Input type="date" value={v.fecha} onChange={(e) => setV({ ...v, fecha: e.target.value })} required /></Campo>
          <Campo label="Etapa" className="col-span-2">
            <Select value={v.etapa ?? ''} onChange={(e) => setV({ ...v, etapa: Number(e.target.value) })} required>
              {etapas.map((e) => <option key={e.id} value={e.id}>{e.numero}ª {e.nombre}</option>)}
            </Select>
          </Campo>
          <Campo label="Consigna o descripción" className="col-span-2"><Textarea value={v.descripcion} onChange={(e) => setV({ ...v, descripcion: e.target.value })} /></Campo>
          {indicadores.length > 0 && (
            <div className="col-span-2">
              <p className="mb-1 text-sm font-bold text-grafito-600">Indicadores que evalúa</p>
              <div className="max-h-56 overflow-y-auto rounded-control border border-grafito-200 px-3">
                {indicadores.map((i: any) => (
                  <Casilla key={i.id} checked={v.indicadores.includes(i.id)}
                    onChange={(on) => setV({ ...v, indicadores: on ? [...v.indicadores, i.id] : v.indicadores.filter((x: number) => x !== i.id) })}>
                    {i.descripcion} <span className="text-sm text-grafito-500">· U{i.unidad.numero}</span>
                  </Casilla>
                ))}
              </div>
            </div>
          )}
          {error && <div className="col-span-2"><ErrorCaja error={error} /></div>}
        </form>
      </Hoja>
      <Confirmar abierta={borrar} titulo="Eliminar trabajo" texto="Se borran también los puntajes cargados." onConfirmar={eliminar} onCerrar={() => setBorrar(false)} />
    </>
  )
}

/** Carga de puntajes de todo el curso. */
function Puntajes({ instrumento, etapas, onVolver }: { instrumento: any; etapas: any[]; onVolver: () => void }) {
  const qc = useQueryClient()
  const avisar = useAviso()
  const datos = useQuery({ queryKey: ['puntajes', instrumento.id], queryFn: () => api(`/instrumentos/${instrumento.id}/puntajes/`) })
  const [valores, setValores] = useState<Record<number, string>>({})
  const [cargado, setCargado] = useState(false)
  const [guardando, setGuardando] = useState(false)
  const [editar, setEditar] = useState(false)

  if (datos.data && !cargado) {
    setValores(Object.fromEntries(datos.data.alumnos.map((a: any) => [a.matricula, num(a.puntaje)])))
    setCargado(true)
  }
  if (datos.isLoading || !cargado) return <Cargando />
  const t = datos.data.instrumento
  const total = Number(t.puntaje_total)
  const fuera = (s: string) => s !== '' && (Number(s) < 0 || Number(s) > total || Number.isNaN(Number(s)))
  const hayError = Object.values(valores).some(fuera)
  const cargados = Object.values(valores).filter((s) => s !== '').length

  const guardar = async () => {
    setGuardando(true)
    try {
      const r = await api(`/instrumentos/${t.id}/puntajes/`, {
        method: 'POST',
        body: { puntajes: datos.data.alumnos.map((a: any) => ({ matricula: a.matricula, puntaje: valores[a.matricula] === '' ? null : valores[a.matricula] })) },
      })
      qc.setQueryData(['puntajes', t.id], r)
      void qc.invalidateQueries({ queryKey: ['instrumentos'] })
      void qc.invalidateQueries({ queryKey: ['planilla'] })
      avisar('Puntajes guardados')
    } catch (e) {
      avisar(e instanceof Error ? e.message : 'No se pudo guardar.', 'error')
    } finally {
      setGuardando(false)
    }
  }

  return (
    <div>
      <button onClick={onVolver} className="mb-3 flex items-center gap-1 text-sm font-bold text-tinta-600"><ChevronLeft className="size-4" /> Trabajos</button>
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold leading-tight">{t.titulo}</h2>
          <p className="text-grafito-500">{tipoTexto(t.tipo)} · {fechaCorta(t.fecha)} · total {num(t.puntaje_total)} puntos</p>
        </div>
        <Boton variante="fantasma" onClick={() => setEditar(true)}>Editar</Boton>
      </div>

      <ul className="divide-y divide-grafito-100 overflow-hidden rounded-xl border border-grafito-200 bg-white">
        {datos.data.alumnos.map((a: any, i: number) => {
          const val = valores[a.matricula] ?? ''
          const mal = fuera(val)
          return (
            <li key={a.matricula} className="flex items-center gap-3 px-4 py-2">
              <span className="w-6 shrink-0 text-right text-sm font-bold text-grafito-500">{a.numero_lista ?? i + 1}</span>
              <label htmlFor={`p-${a.matricula}`} className="min-w-0 flex-1 truncate font-bold">{a.alumno}</label>
              <div className="flex items-center gap-1.5">
                <input id={`p-${a.matricula}`} type="number" inputMode="decimal" step="0.5" min="0" max={total}
                  value={val} onChange={(e) => setValores({ ...valores, [a.matricula]: e.target.value })}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') (document.getElementById(`p-${datos.data.alumnos[i + 1]?.matricula}`) as HTMLInputElement | null)?.focus()
                  }}
                  enterKeyHint="next"
                  className={cn('h-11 w-18 rounded-control border text-center text-lg font-bold focus:outline-none focus:ring-2',
                    mal ? 'border-ausente bg-ausente-50 text-ausente focus:ring-ausente-50' : 'border-grafito-200 focus:border-tinta-500 focus:ring-tinta-100')} />
                <span className="w-9 text-sm text-grafito-500">/ {num(t.puntaje_total)}</span>
              </div>
            </li>
          )
        })}
      </ul>
      <p className="mt-2 text-sm text-grafito-500">Dejá vacío si el alumno no entregó. Con Enter pasás al siguiente.</p>

      <div className="sticky bottom-[5.25rem] z-20 mt-4 lg:bottom-4">
        <div className="flex items-center gap-3 rounded-2xl bg-grafito px-4 py-3 text-white shadow-xl">
          <p className="flex-1 text-sm font-bold">{hayError ? <span className="text-[#ff8f88]">Hay puntajes fuera de 0 a {num(t.puntaje_total)}</span> : `${cargados} de ${datos.data.alumnos.length} cargados`}</p>
          <Boton variante="secundario" onClick={guardar} cargando={guardando} disabled={hayError} className="ring-0">Guardar puntajes</Boton>
        </div>
      </div>

      {editar && (
        <FormTrabajo asignacion={t.asignacion} etapas={etapas} etapa={t.etapa}
          registro={t} onCerrar={() => { setEditar(false); void datos.refetch(); setCargado(false) }} onEliminado={onVolver} />
      )}
    </div>
  )
}

/** Planilla de la etapa: alumnos × trabajos, total logrado y porcentaje. */
function Planilla({ asignacion, etapa }: { asignacion: number; etapa: number }) {
  const p = useQuery({ queryKey: ['planilla', asignacion, etapa], queryFn: () => api(`/planilla/?asignacion=${asignacion}&etapa=${etapa}`, { cache: true }) })
  if (p.isLoading) return <Cargando />
  if (p.error) return <ErrorCaja error={p.error} />
  const d = p.data
  if (!d.trabajos.length) return <Vacio titulo="Sin trabajos en esta etapa" />
  return (
    <div className="overflow-x-auto rounded-xl border border-grafito-200 bg-white">
      <table className="w-full min-w-max text-left">
        <thead className="border-b border-grafito-200 bg-grafito-100/60 text-sm">
          <tr>
            <th className="sticky left-0 bg-grafito-100 px-3 py-2 font-bold">Alumno</th>
            {d.trabajos.map((t: any) => (
              <th key={t.id} className="max-w-28 px-2 py-2 text-center font-bold" title={t.titulo}>
                <span className="block truncate">{t.titulo}</span>
                <span className="font-normal text-grafito-500">{num(t.puntaje_total)} p</span>
              </th>
            ))}
            <th className="px-3 py-2 text-center font-bold">Total<span className="block font-normal text-grafito-500">{num(d.total_posible)} p</span></th>
            <th className="px-3 py-2 text-center font-bold">%</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-grafito-100">
          {d.alumnos.map((a: any) => (
            <tr key={a.matricula}>
              <td className="sticky left-0 bg-white px-3 py-2.5 font-bold"><span className="mr-2 text-sm text-grafito-500">{a.numero_lista}</span>{a.alumno}</td>
              {a.puntajes.map((v: any, i: number) => (
                <td key={i} className={cn('px-2 text-center', v == null && 'text-grafito-300')}>{v == null ? '—' : num(v)}</td>
              ))}
              <td className="px-3 text-center font-bold">{num(a.logrado)}</td>
              <td className="px-3 text-center font-bold text-tinta-700">{a.porcentaje ?? '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
