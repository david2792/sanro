from django.db import transaction
from rest_framework import serializers

from .models import (Capacidad, Indicador, Instrumento, Puntaje, RegistroAnecdotico,
                     RegistroClase, Unidad)


def verificar_asignacion(request, asignacion):
    """Un docente solo trabaja sobre sus propias asignaciones; gestión sobre todas."""
    user = request.user
    if user.es_gestion:
        return
    docente = getattr(user, "docente", None)
    if docente is None or asignacion.docente_id != docente.id:
        raise serializers.ValidationError("Solo podés registrar datos en tus propias clases.")


# --------------------------- Planificación ---------------------------------

class IndicadorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Indicador
        fields = ["id", "capacidad", "orden", "descripcion"]
        extra_kwargs = {"capacidad": {"required": False}}

    def validate(self, data):
        capacidad = data.get("capacidad") or getattr(self.instance, "capacidad", None)
        if capacidad and "request" in self.context:
            verificar_asignacion(self.context["request"], capacidad.unidad.asignacion)
        return data


class CapacidadSerializer(serializers.ModelSerializer):
    indicadores = IndicadorSerializer(many=True, required=False)

    class Meta:
        model = Capacidad
        fields = ["id", "unidad", "orden", "descripcion", "indicadores"]
        extra_kwargs = {"unidad": {"required": False}}

    def validate(self, data):
        unidad = data.get("unidad") or getattr(self.instance, "unidad", None)
        if unidad and "request" in self.context:
            verificar_asignacion(self.context["request"], unidad.asignacion)
        return data

    @transaction.atomic
    def create(self, data):
        indicadores = data.pop("indicadores", [])
        capacidad = Capacidad.objects.create(**data)
        for i in indicadores:
            i.pop("capacidad", None)
            Indicador.objects.create(capacidad=capacidad, **i)
        return capacidad

    def update(self, instance, data):
        data.pop("indicadores", None)  # los indicadores se editan en /api/indicadores/
        return super().update(instance, data)


class UnidadSerializer(serializers.ModelSerializer):
    """
    Se puede crear la unidad completa en un solo POST:
    {asignacion, etapa, numero, titulo, competencia,
     capacidades: [{descripcion, indicadores: [{descripcion}, ...]}, ...]}
    Para editar después, usar /api/capacidades/ y /api/indicadores/.
    """

    capacidades = CapacidadSerializer(many=True, required=False)

    class Meta:
        model = Unidad
        fields = ["id", "asignacion", "etapa", "numero", "titulo", "competencia", "capacidades", "creado"]

    def validate(self, data):
        asignacion = data.get("asignacion") or self.instance.asignacion
        verificar_asignacion(self.context["request"], asignacion)
        etapa = data.get("etapa")
        if etapa and etapa.anio_lectivo_id != asignacion.seccion.anio_lectivo_id:
            raise serializers.ValidationError("La etapa no corresponde al año lectivo de la sección.")
        return data

    @transaction.atomic
    def create(self, data):
        capacidades = data.pop("capacidades", [])
        unidad = Unidad.objects.create(**data)
        for orden, c in enumerate(capacidades, start=1):
            indicadores = c.pop("indicadores", [])
            c.pop("unidad", None)
            c.setdefault("orden", orden)
            capacidad = Capacidad.objects.create(unidad=unidad, **c)
            for o, i in enumerate(indicadores, start=1):
                i.pop("capacidad", None)
                i.setdefault("orden", o)
                Indicador.objects.create(capacidad=capacidad, **i)
        return unidad

    def update(self, instance, data):
        data.pop("capacidades", None)
        return super().update(instance, data)


# --------------------------- Registro de clase ------------------------------

class RegistroClaseSerializer(serializers.ModelSerializer):
    fecha = serializers.DateField(source="sesion.fecha", read_only=True)
    asignacion = serializers.IntegerField(source="sesion.asignacion_id", read_only=True)
    unidad_titulo = serializers.CharField(source="unidad.__str__", read_only=True, default=None)

    class Meta:
        model = RegistroClase
        fields = ["id", "sesion", "fecha", "asignacion", "unidad", "unidad_titulo", "capacidades",
                  "indicadores_evaluados", "contenido", "actividades", "observaciones", "creado", "modificado"]

    def validate(self, data):
        sesion = data.get("sesion") or self.instance.sesion
        asignacion = sesion.asignacion
        verificar_asignacion(self.context["request"], asignacion)
        unidad = data.get("unidad")
        if unidad and unidad.asignacion_id != asignacion.id:
            raise serializers.ValidationError("La unidad no pertenece a esta clase.")
        for c in data.get("capacidades", []):
            if c.unidad.asignacion_id != asignacion.id:
                raise serializers.ValidationError(f"La capacidad {c.id} no pertenece a esta clase.")
        for i in data.get("indicadores_evaluados", []):
            if i.capacidad.unidad.asignacion_id != asignacion.id:
                raise serializers.ValidationError(f"El indicador {i.id} no pertenece a esta clase.")
        return data


# --------------------------- Registro anecdótico ----------------------------

class RegistroAnecdoticoSerializer(serializers.ModelSerializer):
    alumnos_nombres = serializers.SerializerMethodField()
    asignacion_descripcion = serializers.CharField(source="asignacion.__str__", read_only=True)
    registrado_por_nombre = serializers.CharField(source="registrado_por.__str__", read_only=True, default=None)

    class Meta:
        model = RegistroAnecdotico
        fields = "__all__"
        read_only_fields = ["registrado_por"]

    def get_alumnos_nombres(self, obj):
        return [str(m.alumno) for m in obj.alumnos.all()]

    def validate(self, data):
        asignacion = data.get("asignacion") or self.instance.asignacion
        verificar_asignacion(self.context["request"], asignacion)
        alumnos = data.get("alumnos")
        if alumnos is not None:
            if not alumnos:
                raise serializers.ValidationError("Indicá al menos un alumno involucrado.")
            for m in alumnos:
                if m.seccion_id != asignacion.seccion_id:
                    raise serializers.ValidationError(f"{m.alumno} no pertenece a la sección de esta clase.")
        return data


# --------------------------- Trabajos y puntajes ----------------------------

class InstrumentoSerializer(serializers.ModelSerializer):
    etapa_nombre = serializers.CharField(source="etapa.__str__", read_only=True)
    evaluados = serializers.IntegerField(read_only=True, required=False)

    class Meta:
        model = Instrumento
        fields = "__all__"

    def validate(self, data):
        asignacion = data.get("asignacion") or self.instance.asignacion
        verificar_asignacion(self.context["request"], asignacion)
        etapa = data.get("etapa")
        if etapa and etapa.anio_lectivo_id != asignacion.seccion.anio_lectivo_id:
            raise serializers.ValidationError("La etapa no corresponde al año lectivo de la sección.")
        total = data.get("puntaje_total")
        if total is not None and total <= 0:
            raise serializers.ValidationError("El puntaje total debe ser mayor a cero.")
        if total is not None and self.instance:
            maximo = self.instance.puntajes.exclude(puntaje=None).order_by("-puntaje").first()
            if maximo and maximo.puntaje > total:
                raise serializers.ValidationError(
                    f"Ya hay alumnos con {maximo.puntaje} puntos; el total no puede ser menor.")
        for i in data.get("indicadores", []):
            if i.capacidad.unidad.asignacion_id != asignacion.id:
                raise serializers.ValidationError(f"El indicador {i.id} no pertenece a esta clase.")
        return data


class PuntajeItemSerializer(serializers.Serializer):
    matricula = serializers.IntegerField()
    puntaje = serializers.DecimalField(max_digits=6, decimal_places=2, allow_null=True)
    observacion = serializers.CharField(required=False, allow_blank=True, default="")


class PuntajesLoteSerializer(serializers.Serializer):
    """Carga de puntajes de todo el curso: {puntajes: [{matricula, puntaje, observacion}]}"""

    puntajes = PuntajeItemSerializer(many=True)

    def validate_puntajes(self, items):
        instrumento = self.context["instrumento"]
        validas = set(instrumento.asignacion.seccion.matriculas.values_list("id", flat=True))
        errores = []
        for it in items:
            if it["matricula"] not in validas:
                errores.append(f"La matrícula {it['matricula']} no pertenece a esta sección.")
            p = it["puntaje"]
            if p is not None and (p < 0 or p > instrumento.puntaje_total):
                errores.append(f"Matrícula {it['matricula']}: el puntaje {p} debe estar entre 0 "
                               f"y {instrumento.puntaje_total}.")
        if errores:
            raise serializers.ValidationError(errores)
        return items

    @transaction.atomic
    def save(self, **kwargs):
        instrumento = self.context["instrumento"]
        user = self.context["request"].user
        for it in self.validated_data["puntajes"]:
            Puntaje.objects.update_or_create(
                instrumento=instrumento, matricula_id=it["matricula"],
                defaults={"puntaje": it["puntaje"], "observacion": it.get("observacion", ""),
                          "registrado_por": user},
            )
        return instrumento


class LogroItemSerializer(serializers.Serializer):
    matricula = serializers.IntegerField()
    indicador = serializers.IntegerField()
    estado = serializers.ChoiceField(choices=["L", "NL"], allow_null=True)


class LogrosLoteSerializer(serializers.Serializer):
    """{logros: [{matricula, indicador, estado: 'L' | 'NL' | null}]}  (null = borrar la marca)"""

    logros = LogroItemSerializer(many=True)

    def validate_logros(self, items):
        unidad = self.context["unidad"]
        indicadores = set(Indicador.objects.filter(capacidad__unidad=unidad).values_list("id", flat=True))
        matriculas = set(unidad.asignacion.seccion.matriculas.values_list("id", flat=True))
        for it in items:
            if it["indicador"] not in indicadores:
                raise serializers.ValidationError(f"El indicador {it['indicador']} no pertenece a esta unidad.")
            if it["matricula"] not in matriculas:
                raise serializers.ValidationError(f"La matrícula {it['matricula']} no pertenece a esta sección.")
        return items

    @transaction.atomic
    def save(self, **kwargs):
        from .models import LogroIndicador

        user = self.context["request"].user
        for it in self.validated_data["logros"]:
            if it["estado"] is None:
                LogroIndicador.objects.filter(indicador_id=it["indicador"], matricula_id=it["matricula"]).delete()
            else:
                LogroIndicador.objects.update_or_create(
                    indicador_id=it["indicador"], matricula_id=it["matricula"],
                    defaults={"estado": it["estado"], "registrado_por": user},
                )
