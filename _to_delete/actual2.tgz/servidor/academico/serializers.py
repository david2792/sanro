from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import serializers

from .models import (AnioLectivo, Asignacion, Curso, DiaNoLectivo, Especialidad, Etapa,
                     Institucion, Materia, Matricula, Nivel, PlanMateria, Seccion)


class InstitucionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Institucion
        fields = "__all__"


class AnioLectivoSerializer(serializers.ModelSerializer):
    class Meta:
        model = AnioLectivo
        fields = "__all__"


class EtapaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Etapa
        fields = "__all__"


class DiaNoLectivoSerializer(serializers.ModelSerializer):
    class Meta:
        model = DiaNoLectivo
        fields = "__all__"


class NivelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Nivel
        fields = "__all__"


class EspecialidadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Especialidad
        fields = "__all__"


class CursoSerializer(serializers.ModelSerializer):
    descripcion = serializers.CharField(source="__str__", read_only=True)

    class Meta:
        model = Curso
        fields = "__all__"


class MateriaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Materia
        fields = "__all__"


class PlanMateriaSerializer(serializers.ModelSerializer):
    materia_nombre = serializers.CharField(source="materia.nombre", read_only=True)

    class Meta:
        model = PlanMateria
        fields = "__all__"


class SeccionSerializer(serializers.ModelSerializer):
    descripcion = serializers.CharField(source="__str__", read_only=True)
    inscriptos = serializers.IntegerField(read_only=True)

    class Meta:
        model = Seccion
        fields = "__all__"


class AsignacionSerializer(serializers.ModelSerializer):
    materia_nombre = serializers.CharField(source="materia.nombre", read_only=True)
    seccion_descripcion = serializers.CharField(source="seccion.__str__", read_only=True)
    docente_nombre = serializers.CharField(source="docente.__str__", read_only=True)

    class Meta:
        model = Asignacion
        fields = "__all__"


class MatriculaSerializer(serializers.ModelSerializer):
    alumno_nombre = serializers.CharField(source="alumno.__str__", read_only=True)
    alumno_ci = serializers.CharField(source="alumno.ci", read_only=True)
    seccion_descripcion = serializers.CharField(source="seccion.__str__", read_only=True)

    class Meta:
        model = Matricula
        fields = "__all__"
        read_only_fields = ["anio_lectivo"]
        validators = []  # la unicidad alumno/año se valida en Matricula.clean()

    def validate(self, data):
        instancia = Matricula(**{**({f.name: getattr(self.instance, f.name) for f in Matricula._meta.concrete_fields}
                                    if self.instance else {}), **data})
        try:
            instancia.clean()
        except DjangoValidationError as e:
            raise serializers.ValidationError(e.messages)
        return data
