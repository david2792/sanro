// Service worker mínimo: guarda la app para abrirla sin señal.
// Los datos (API) siempre van a la red; si no hay, la app usa su propia caché.
const CACHE = 'sanroque-v1'
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(['/', '/index.html'])))
  self.skipWaiting()
})
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))))
  self.clients.claim()
})
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url)
  if (e.request.method !== 'GET' || url.pathname.startsWith('/api') || url.pathname.startsWith('/media')) return
  e.respondWith(
    fetch(e.request)
      .then((r) => {
        const copia = r.clone()
        caches.open(CACHE).then((c) => c.put(e.request, copia))
        return r
      })
      .catch(() => caches.match(e.request).then((r) => r || caches.match('/index.html'))),
  )
})
