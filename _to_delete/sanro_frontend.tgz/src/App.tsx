import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import type { ReactNode } from 'react'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router'
import Layout from './components/Layout'
import { REFERENCIALES } from './pages/gestion/referenciales'
import { CrudPage } from './components/Crud'
import { AvisosProvider, Cargando } from './components/ui'
import { AuthProvider, useAuth } from './lib/auth'
import Login from './pages/Login'
import Perfil from './pages/Perfil'
import Clase from './pages/docente/Clase'
import MisClases from './pages/docente/MisClases'
import { AlumnoDetalle, CursoDetalle, SeccionDetalle } from './pages/gestion/Detalles'
import { GestionInicio, RefPage } from './pages/gestion/Gestion'
import Tablero from './pages/gestion/Tablero'

const qc = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 15_000 } },
})

function Protegida({ children, soloGestion }: { children: ReactNode; soloGestion?: boolean }) {
  const { usuario, cargando, esGestion } = useAuth()
  if (cargando && !usuario) return <Cargando />
  if (!usuario) return <Navigate to="/login" replace />
  if (soloGestion && !esGestion) return <Navigate to="/" replace />
  return children
}

function Inicio() {
  const { esGestion, esDocente } = useAuth()
  return <Navigate to={esGestion ? '/tablero' : esDocente ? '/clases' : '/perfil'} replace />
}

export default function App() {
  return (
    <QueryClientProvider client={qc}>
      <AuthProvider>
        <AvisosProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route element={<Protegida><Layout /></Protegida>}>
                <Route index element={<Inicio />} />
                <Route path="clases" element={<MisClases />} />
                <Route path="clases/:id" element={<Clase />} />
                <Route path="perfil" element={<Perfil />} />
                <Route path="tablero" element={<Protegida soloGestion><Tablero /></Protegida>} />
                <Route path="alumnos" element={<Protegida soloGestion><CrudPage config={REFERENCIALES.alumnos} /></Protegida>} />
                <Route path="alumnos/:id" element={<Protegida soloGestion><AlumnoDetalle /></Protegida>} />
                <Route path="secciones/:id" element={<Protegida soloGestion><SeccionDetalle /></Protegida>} />
                <Route path="cursos/:id" element={<Protegida soloGestion><CursoDetalle /></Protegida>} />
                <Route path="ref" element={<Protegida soloGestion><GestionInicio /></Protegida>} />
                <Route path="ref/:clave" element={<Protegida soloGestion><RefPage /></Protegida>} />
              </Route>
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
        </AvisosProvider>
      </AuthProvider>
    </QueryClientProvider>
  )
}
