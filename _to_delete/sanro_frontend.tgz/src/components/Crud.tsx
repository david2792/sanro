import { useQuery, useQueryClient } from '@tanstack/react-query'
import { ChevronRight, Pencil, Plus, Search } from 'lucide-react'
import { useMemo, useState, type ReactNode } from 'react'
import { useNavigate } from 'react-router'
import { api, ApiError, cuerpoConArchivos, lista, mensajeDeError } from '../lib/api'
import { cn } from '../lib/utils'
import { Boton, Campo, Cargando, Casilla, Confirmar, Encabezado, ErrorCaja, Hoja, Input, Select, Textarea, useAviso, Vacio } from './ui'

export type CampoDef = {
  name: string
  label: string
  tipo?: 'texto' | 'numero' | 'fecha' | 'hora' | 'area' | 'select' | 'fk' | 'fk_multiple' | 'si_no' | 'archivo' | 'password' | 'email' | 'tel'
  opciones?: { valor: string; label: string }[]
  fk?: { ruta: string; label: (o: any) => string }
  requerido?: boolean
  ayuda?: string
  medio?: boolean
  /** Si se define, el campo se muestra solo cuando devuelve true. */
  visible?: (valores: Record<string, any>) => boolean
}

export type ColDef = { label: string; valor: (o: any) => ReactNode; principal?: boolean; oculto_movil?: boolean }

export type CrudConfig = {
  titulo: string
  singular: string
  ruta: string
  descripcion?: string
  columnas: ColDef[]
  campos: CampoDef[]
  inicial?: () => Record<string, any>
  enlace?: (o: any) => string
  buscar?: (o: any) => string
  ordenar?: (a: any, b: any) => number
  soloLectura?: boolean
  /** Para concordar: "Nueva materia", "Materia creada". */
  femenino?: boolean
}

/* ---------------------------- Opciones de FK ---------------------------- */

export function useOpciones(ruta?: string) {
  return useQuery({ queryKey: ['opciones', ruta], queryFn: () => lista(ruta!), enabled: !!ruta, staleTime: 60_000 })
}

function CampoFK({ def, valor, onChange }: { def: CampoDef; valor: any; onChange: (v: any) => void }) {
  const { data = [], isLoading } = useOpciones(def.fk!.ruta)
  if (def.tipo === 'fk_multiple') {
    const sel: number[] = valor ?? []
    return (
      <div className="max-h-56 overflow-y-auto rounded-control border border-grafito-200 px-3">
        {isLoading && <p className="py-2 text-grafito-500">Cargando…</p>}
        {data.map((o: any) => (
          <Casilla key={o.id} checked={sel.includes(o.id)}
            onChange={(c) => onChange(c ? [...sel, o.id] : sel.filter((x) => x !== o.id))}>
            {def.fk!.label(o)}
          </Casilla>
        ))}
      </div>
    )
  }
  return (
    <Select value={valor ?? ''} onChange={(e) => onChange(e.target.value === '' ? null : Number(e.target.value))} required={def.requerido}>
      <option value="">{isLoading ? 'Cargando…' : 'Seleccionar…'}</option>
      {data.map((o: any) => <option key={o.id} value={o.id}>{def.fk!.label(o)}</option>)}
    </Select>
  )
}

export function ControlCampo({ def, valor, onChange }: { def: CampoDef; valor: any; onChange: (v: any) => void }) {
  switch (def.tipo) {
    case 'area':
      return <Textarea value={valor ?? ''} onChange={(e) => onChange(e.target.value)} required={def.requerido} />
    case 'select':
      return (
        <Select value={valor ?? ''} onChange={(e) => onChange(e.target.value)} required={def.requerido}>
          {!def.requerido && <option value="">—</option>}
          {def.opciones!.map((o) => <option key={o.valor} value={o.valor}>{o.label}</option>)}
        </Select>
      )
    case 'fk':
    case 'fk_multiple':
      return <CampoFK def={def} valor={valor} onChange={onChange} />
    case 'si_no':
      return <Casilla checked={!!valor} onChange={onChange}>{def.ayuda ?? 'Sí'}</Casilla>
    case 'archivo':
      return (
        <div>
          {typeof valor === 'string' && valor && (
            <a href={valor} target="_blank" rel="noreferrer" className="mb-2 block truncate text-tinta-600 underline">Ver archivo actual</a>
          )}
          <input type="file" accept="image/*,application/pdf" onChange={(e) => onChange(e.target.files?.[0] ?? valor)}
            className="block w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-tinta-50 file:px-4 file:py-2.5 file:font-bold file:text-tinta-700" />
        </div>
      )
    default: {
      const tipos: Record<string, string> = { numero: 'number', fecha: 'date', hora: 'time', password: 'password', email: 'email', tel: 'tel' }
      const tipo = tipos[def.tipo ?? ''] ?? 'text'
      return (
        <Input type={tipo} value={valor ?? ''} required={def.requerido}
          inputMode={def.tipo === 'numero' ? 'decimal' : def.tipo === 'tel' ? 'tel' : undefined}
          onChange={(e) => onChange(def.tipo === 'numero' ? (e.target.value === '' ? null : e.target.value) : e.target.value)} />
      )
    }
  }
}

/* ---------------------------- Formulario -------------------------------- */

export function FormularioCrud({ config, abierto, registro, fijos, onCerrar, onGuardado }: {
  config: CrudConfig
  abierto: boolean
  registro: any | null
  fijos?: Record<string, any>
  onCerrar: () => void
  onGuardado?: (r: any) => void
}) {
  const qc = useQueryClient()
  const avisar = useAviso()
  const [valores, setValores] = useState<Record<string, any>>({})
  const [errores, setErrores] = useState<Record<string, string>>({})
  const [errorGeneral, setErrorGeneral] = useState('')
  const [guardando, setGuardando] = useState(false)
  const [borrar, setBorrar] = useState(false)
  const [abiertoPrevio, setAbiertoPrevio] = useState(false)

  // Reinicia el formulario cada vez que se abre.
  if (abierto !== abiertoPrevio) {
    setAbiertoPrevio(abierto)
    if (abierto) {
      setValores(registro ? { ...registro } : { ...(config.inicial?.() ?? {}), ...fijos })
      setErrores({})
      setErrorGeneral('')
    }
  }

  const campos = config.campos.filter((c) => !(fijos && c.name in fijos) && (!c.visible || c.visible(valores)))

  const guardar = async (e: React.FormEvent) => {
    e.preventDefault()
    setGuardando(true)
    setErrores({})
    setErrorGeneral('')
    try {
      const datos: Record<string, any> = { ...fijos }
      for (const c of config.campos) {
        if (!(c.name in valores)) continue
        const v = valores[c.name]
        if (c.tipo === 'archivo' && !(v instanceof File)) continue
        if (c.tipo === 'password' && !v) continue
        datos[c.name] = v === '' && (c.tipo === 'fecha' || c.tipo === 'hora' || c.tipo === 'numero') ? null : v
      }
      const r = registro
        ? await api(`${config.ruta}${registro.id}/`, { method: 'PATCH', body: cuerpoConArchivos(datos) })
        : await api(config.ruta, { method: 'POST', body: cuerpoConArchivos(datos) })
      await qc.invalidateQueries()
      avisar(`${config.singular} ${registro ? (config.femenino ? 'actualizada' : 'actualizado') : config.femenino ? 'creada' : 'creado'}`)
      onGuardado?.(r)
      onCerrar()
    } catch (err) {
      if (err instanceof ApiError && err.data && typeof err.data === 'object' && !Array.isArray(err.data)) {
        const porCampo: Record<string, string> = {}
        const resto: string[] = []
        for (const [k, v] of Object.entries(err.data)) {
          if (config.campos.some((c) => c.name === k)) porCampo[k] = mensajeDeError(v)
          else resto.push(mensajeDeError(v))
        }
        setErrores(porCampo)
        setErrorGeneral(resto.join(' '))
      } else setErrorGeneral(err instanceof Error ? err.message : 'No se pudo guardar.')
    } finally {
      setGuardando(false)
    }
  }

  const eliminar = async () => {
    setGuardando(true)
    try {
      await api(`${config.ruta}${registro.id}/`, { method: 'DELETE' })
      await qc.invalidateQueries()
      avisar(`${config.singular} ${config.femenino ? 'eliminada' : 'eliminado'}`)
      setBorrar(false)
      onCerrar()
    } catch (err) {
      setBorrar(false)
      setErrorGeneral(err instanceof Error ? err.message : 'No se pudo eliminar.')
    } finally {
      setGuardando(false)
    }
  }

  return (
    <>
      <Hoja abierta={abierto} onCerrar={onCerrar} titulo={registro ? `Editar ${config.singular.toLowerCase()}` : `${config.femenino ? 'Nueva' : 'Nuevo'} ${config.singular.toLowerCase()}`}
        pie={<>
          {registro && !config.soloLectura && <Boton type="button" variante="secundario" className="text-ausente" onClick={() => setBorrar(true)}>Eliminar</Boton>}
          <Boton type="submit" form="form-crud" className="flex-1" cargando={guardando}>Guardar</Boton>
        </>}>
        <form id="form-crud" onSubmit={guardar} className="grid grid-cols-2 gap-x-3 gap-y-4">
          {campos.map((c) => (
            <Campo key={c.name} label={c.label + (c.requerido ? '' : '')} ayuda={c.tipo === 'si_no' ? undefined : c.ayuda} error={errores[c.name]}
              className={c.medio ? 'col-span-1' : 'col-span-2'}>
              <ControlCampo def={c} valor={valores[c.name]} onChange={(v) => setValores((s) => ({ ...s, [c.name]: v }))} />
            </Campo>
          ))}
          {errorGeneral && <div className="col-span-2"><ErrorCaja error={errorGeneral} /></div>}
        </form>
      </Hoja>
      <Confirmar abierta={borrar} titulo={`Eliminar ${config.singular.toLowerCase()}`} cargando={guardando}
        texto="Esta acción no se puede deshacer. Si el registro ya se usa en otros datos, el sistema no lo va a permitir."
        onConfirmar={eliminar} onCerrar={() => setBorrar(false)} />
    </>
  )
}

/* ---------------------------- Página de listado ------------------------- */

export function CrudPage({ config, filtro = '', fijos, embebido }: {
  config: CrudConfig
  /** Query string extra, ej. "seccion=3" */
  filtro?: string
  /** Valores fijos para los registros nuevos (y campos ocultos), ej. {seccion: 3} */
  fijos?: Record<string, any>
  embebido?: boolean
}) {
  const navegar = useNavigate()
  const [q, setQ] = useState('')
  const [editando, setEditando] = useState<any | null>(null)
  const [abierto, setAbierto] = useState(false)
  const ruta = config.ruta + (filtro ? `?${filtro}` : '')
  const { data, isLoading, error } = useQuery({ queryKey: ['lista', ruta], queryFn: () => lista(ruta) })

  const filas = useMemo(() => {
    let r = data ?? []
    if (config.ordenar) r = [...r].sort(config.ordenar)
    if (!q.trim()) return r
    const t = q.toLowerCase()
    return r.filter((o) => (config.buscar?.(o) ?? config.columnas.map((c) => String(c.valor(o) ?? '')).join(' ')).toLowerCase().includes(t))
  }, [data, q, config])

  const abrir = (o: any | null) => {
    setEditando(o)
    setAbierto(true)
  }
  const tocar = (o: any) => (config.enlace ? navegar(config.enlace(o)) : !config.soloLectura && abrir(o))
  const principal = config.columnas.find((c) => c.principal) ?? config.columnas[0]
  const resto = config.columnas.filter((c) => c !== principal)

  const botonNuevo = !config.soloLectura && (
    <Boton onClick={() => abrir(null)}><Plus className="size-5" /> {embebido ? 'Agregar' : `${config.femenino ? 'Nueva' : 'Nuevo'} ${config.singular.toLowerCase()}`}</Boton>
  )

  return (
    <div>
      {embebido ? (
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold">{config.titulo}</h2>
          {botonNuevo}
        </div>
      ) : (
        <Encabezado titulo={config.titulo} detalle={config.descripcion} acciones={botonNuevo} />
      )}

      {(data?.length ?? 0) > 8 && (
        <div className="relative mb-4">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-5 -translate-y-1/2 text-grafito-500" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar…" className="pl-10" aria-label="Buscar" />
        </div>
      )}

      {isLoading && <Cargando />}
      <ErrorCaja error={error} />
      {data && !filas.length && (
        <Vacio titulo={q ? 'Sin resultados' : `Todavía no hay ${config.titulo.toLowerCase()}`}
          texto={q ? 'Probá con otra palabra.' : undefined} accion={!q && botonNuevo} />
      )}

      {!!filas.length && (
        <>
          {/* Celular: lista */}
          <ul className="divide-y divide-grafito-100 overflow-hidden rounded-xl border border-grafito-200 bg-white md:hidden">
            {filas.map((o) => (
              <li key={o.id}>
                <button onClick={() => tocar(o)} className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-tinta-50">
                  <div className="min-w-0 flex-1">
                    <p className="font-bold">{principal.valor(o)}</p>
                    <p className="truncate text-sm text-grafito-500">
                      {resto.filter((c) => !c.oculto_movil).map((c) => c.valor(o)).filter((v) => v !== '' && v != null).map((v, i) => (
                        <span key={i}>{i > 0 && ' · '}{v}</span>
                      ))}
                    </p>
                  </div>
                  {config.enlace ? <ChevronRight className="size-5 text-grafito-300" /> : !config.soloLectura && <Pencil className="size-4 text-grafito-300" />}
                </button>
              </li>
            ))}
          </ul>

          {/* Pantalla grande: tabla */}
          <div className="hidden overflow-hidden rounded-xl border border-grafito-200 bg-white md:block">
            <table className="w-full text-left">
              <thead className="border-b border-grafito-200 bg-grafito-100/60 text-sm text-grafito-600">
                <tr>
                  {config.columnas.map((c) => <th key={c.label} className="px-4 py-2.5 font-bold">{c.label}</th>)}
                  <th className="w-12" />
                </tr>
              </thead>
              <tbody className="divide-y divide-grafito-100">
                {filas.map((o) => (
                  <tr key={o.id} onClick={() => tocar(o)} className={cn('cursor-pointer hover:bg-tinta-50/60')}>
                    {config.columnas.map((c) => (
                      <td key={c.label} className={cn('px-4 py-3', c === principal && 'font-bold')}>{c.valor(o)}</td>
                    ))}
                    <td className="pr-3 text-right">
                      {config.enlace && !config.soloLectura ? (
                        <button onClick={(e) => { e.stopPropagation(); abrir(o) }} className="rounded-lg p-2 text-grafito-500 hover:bg-white" aria-label="Editar">
                          <Pencil className="size-4" />
                        </button>
                      ) : config.enlace ? <ChevronRight className="size-5 text-grafito-300" /> : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-sm text-grafito-500">{filas.length} {filas.length === 1 ? 'registro' : 'registros'}</p>
        </>
      )}

      <FormularioCrud config={config} abierto={abierto} registro={editando} fijos={fijos} onCerrar={() => setAbierto(false)} />
    </div>
  )
}
