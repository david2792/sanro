import { BookOpen, CloudOff, GraduationCap, LayoutDashboard, Library, LogOut, RefreshCw, UserRound } from 'lucide-react'
import { useEffect, useState } from 'react'
import { NavLink, Outlet } from 'react-router'
import { ROL_NOMBRE, useAuth } from '../lib/auth'
import { sincronizar, usePendientes } from '../lib/offline'
import { cn, iniciales } from '../lib/utils'

type Item = { a: string; label: string; icono: typeof BookOpen }

function useItems(): Item[] {
  const { esGestion, esDocente } = useAuth()
  const items: Item[] = []
  if (esGestion) items.push({ a: '/tablero', label: 'Tablero', icono: LayoutDashboard })
  if (esDocente) items.push({ a: '/clases', label: 'Mis clases', icono: BookOpen })
  if (esGestion) {
    items.push({ a: '/alumnos', label: 'Alumnos', icono: GraduationCap })
    items.push({ a: '/ref', label: 'Gestión', icono: Library })
  }
  items.push({ a: '/perfil', label: 'Perfil', icono: UserRound })
  return items
}

function useEnLinea() {
  const [en, setEn] = useState(navigator.onLine)
  useEffect(() => {
    const on = () => setEn(true)
    const off = () => setEn(false)
    window.addEventListener('online', on)
    window.addEventListener('offline', off)
    return () => {
      window.removeEventListener('online', on)
      window.removeEventListener('offline', off)
    }
  }, [])
  return en
}

/** Avisa si no hay señal o si quedan listas por enviar. */
function EstadoSync() {
  const pendientes = usePendientes()
  const enLinea = useEnLinea()
  if (enLinea && !pendientes.length) return null
  return (
    <button
      onClick={() => void sincronizar()}
      className={cn('flex items-center gap-1.5 rounded-full px-3 py-1 text-sm font-bold',
        enLinea ? 'bg-tarde-50 text-tarde' : 'bg-grafito-100 text-grafito-600')}
    >
      {enLinea ? <RefreshCw className="size-4" /> : <CloudOff className="size-4" />}
      {pendientes.length ? `${pendientes.length} por enviar` : 'Sin señal'}
    </button>
  )
}

export default function Layout() {
  const { usuario, salir } = useAuth()
  const items = useItems()
  const nombre = usuario ? `${usuario.first_name} ${usuario.last_name}`.trim() || usuario.username : ''

  return (
    <div className="min-h-dvh lg:flex">
      {/* Barra lateral (computadora) */}
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col bg-tinta-900 text-tinta-100 lg:flex">
        <div className="px-6 pb-6 pt-7">
          <p className="text-lg font-bold leading-tight text-white">San Roque González</p>
          <p className="text-sm text-tinta-200">Gestión académica</p>
        </div>
        <nav className="flex-1 space-y-1 px-3">
          {items.map(({ a, label, icono: I }) => (
            <NavLink key={a} to={a}
              className={({ isActive }) => cn('flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold',
                isActive ? 'bg-white/12 text-white' : 'text-tinta-200 hover:bg-white/6 hover:text-white')}>
              <I className="size-5" /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="flex items-center gap-3 border-t border-white/10 px-5 py-4">
          <span className="grid size-9 place-items-center rounded-full bg-tinta-600 text-sm font-bold text-white">{iniciales(nombre)}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate font-bold text-white">{nombre}</p>
            <p className="text-sm text-tinta-200">{usuario && ROL_NOMBRE[usuario.rol]}</p>
          </div>
          <button onClick={salir} className="rounded-lg p-2 hover:bg-white/10" aria-label="Cerrar sesión"><LogOut className="size-5" /></button>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-grafito-200 bg-papel/95 px-4 backdrop-blur lg:hidden">
          <p className="font-bold text-tinta-700">San Roque</p>
          <EstadoSync />
        </header>
        <div className="hidden justify-end px-8 pt-4 lg:flex"><EstadoSync /></div>
        <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-5 sm:px-6 lg:px-8 lg:pb-12">
          <Outlet />
        </main>
      </div>

      {/* Navegación inferior (celular) */}
      <nav className="pb-safe fixed inset-x-0 bottom-0 z-40 flex border-t border-grafito-200 bg-white pt-1 lg:hidden">
        {items.map(({ a, label, icono: I }) => (
          <NavLink key={a} to={a}
            className={({ isActive }) => cn('flex flex-1 flex-col items-center gap-0.5 py-1.5 text-xs font-bold',
              isActive ? 'text-tinta-700' : 'text-grafito-500')}>
            {({ isActive }) => (
              <>
                <span className={cn('grid h-8 w-14 place-items-center rounded-full', isActive && 'bg-tinta-100')}>
                  <I className="size-5" />
                </span>
                {label}
              </>
            )}
          </NavLink>
        ))}
      </nav>
    </div>
  )
}
