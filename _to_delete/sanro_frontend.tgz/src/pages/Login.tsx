import { useState } from 'react'
import { Navigate } from 'react-router'
import { Boton, Campo, ErrorCaja, Input } from '../components/ui'
import { useAuth } from '../lib/auth'

export default function Login() {
  const { usuario, entrar } = useAuth()
  const [u, setU] = useState('')
  const [p, setP] = useState('')
  const [error, setError] = useState('')
  const [cargando, setCargando] = useState(false)

  if (usuario) return <Navigate to="/" replace />

  const enviar = async (e: React.FormEvent) => {
    e.preventDefault()
    setCargando(true)
    setError('')
    try {
      await entrar(u.trim(), p)
    } catch (err: any) {
      setError(err?.status === 401 ? 'Usuario o contraseña incorrectos.' : err?.message ?? 'No se pudo iniciar sesión.')
    } finally {
      setCargando(false)
    }
  }

  return (
    <div className="flex min-h-dvh flex-col bg-tinta-800 lg:flex-row">
      <div className="px-6 pb-10 pt-14 text-white lg:flex lg:w-1/2 lg:flex-col lg:justify-end lg:p-16">
        <p className="text-tinta-200">Colegio Nacional EMD</p>
        <h1 className="mt-1 max-w-md text-[2.5rem] font-bold leading-[1.05] lg:text-6xl">San Roque González de Santacruz</h1>
        <p className="mt-4 max-w-sm text-lg text-tinta-200">Lista, desarrollo de clases y evaluaciones, desde el celular.</p>
      </div>
      <div className="flex flex-1 items-start justify-center rounded-t-3xl bg-papel px-6 pb-10 pt-8 lg:items-center lg:rounded-none">
        <form onSubmit={enviar} className="w-full max-w-sm space-y-5">
          <h2 className="text-2xl font-bold">Iniciar sesión</h2>
          <Campo label="Usuario">
            <Input value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" autoCapitalize="none" required autoFocus />
          </Campo>
          <Campo label="Contraseña">
            <Input type="password" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" required />
          </Campo>
          <ErrorCaja error={error} />
          <Boton grande type="submit" className="w-full" cargando={cargando}>Entrar</Boton>
          <p className="text-center text-sm text-grafito-500">¿Olvidaste tu contraseña? Pedí a secretaría que la restablezca.</p>
        </form>
      </div>
    </div>
  )
}
