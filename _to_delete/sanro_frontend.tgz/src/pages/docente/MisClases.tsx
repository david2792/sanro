import { useQuery } from '@tanstack/react-query'
import { Check, ChevronRight } from 'lucide-react'
import { Link } from 'react-router'
import { Cargando, ErrorCaja, Vacio } from '../../components/ui'
import { api, lista } from '../../lib/api'
import { useAuth } from '../../lib/auth'
import { usePendientes } from '../../lib/offline'
import { fechaLarga, hoyISO } from '../../lib/utils'

export default function MisClases() {
  const { usuario } = useAuth()
  const hoy = hoyISO()
  const clases = useQuery({ queryKey: ['mias'], queryFn: () => api('/asignaciones/mias/', { cache: true }) })
  const hechas = useQuery({
    queryKey: ['sesiones-hoy', hoy],
    queryFn: () => lista(`/sesiones/?fecha=${hoy}`),
    retry: false,
  })
  const pendientes = usePendientes()
  const listaHecha = (asig: number) =>
    hechas.data?.some((s: any) => s.asignacion === asig) || pendientes.some((p) => p.body.asignacion === asig && p.body.fecha === hoy)

  // Agrupa por sección para que el docente encuentre rápido su curso.
  const porSeccion = new Map<string, any[]>()
  for (const c of clases.data ?? []) {
    porSeccion.set(c.seccion_descripcion, [...(porSeccion.get(c.seccion_descripcion) ?? []), c])
  }

  return (
    <div>
      <p className="text-grafito-500 first-letter:uppercase">{fechaLarga(hoy)}</p>
      <h1 className="mb-6 text-2xl font-bold">Hola, {usuario?.first_name || usuario?.username}</h1>

      {clases.isLoading && <Cargando />}
      <ErrorCaja error={clases.error} />
      {clases.data && !clases.data.length && (
        <Vacio titulo="No tenés clases asignadas este año" texto="Pedí a coordinación que te asigne tus materias y secciones." />
      )}

      <div className="space-y-6">
        {[...porSeccion.entries()].map(([seccion, asignaciones]) => (
          <section key={seccion}>
            <h2 className="mb-2 text-sm font-bold text-grafito-500">{seccion}</h2>
            <ul className="divide-y divide-grafito-100 overflow-hidden rounded-xl border border-grafito-200 bg-white">
              {asignaciones.map((c) => {
                const hecha = listaHecha(c.id)
                return (
                  <li key={c.id}>
                    <Link to={`/clases/${c.id}`} className="flex items-center gap-4 px-4 py-4 active:bg-tinta-50">
                      <span className={`grid size-11 shrink-0 place-items-center rounded-full text-lg font-bold ${hecha ? 'bg-presente text-white' : 'bg-tinta-100 text-tinta-700'}`}>
                        {hecha ? <Check className="size-6" /> : c.materia_nombre[0]}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-lg font-bold leading-tight">{c.materia_nombre}</p>
                        <p className="text-sm text-grafito-500">{hecha ? 'Lista de hoy guardada' : 'Falta llamar lista hoy'}</p>
                      </div>
                      <ChevronRight className="size-5 text-grafito-300" />
                    </Link>
                  </li>
                )
              })}
            </ul>
          </section>
        ))}
      </div>
    </div>
  )
}
