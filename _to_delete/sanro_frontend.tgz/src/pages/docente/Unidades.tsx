import { useQuery, useQueryClient } from '@tanstack/react-query'
import { ChevronDown, Pencil, Plus, Trash2, X } from 'lucide-react'
import { useState } from 'react'
import { Boton, Campo, Cargando, Confirmar, Hoja, Input, Select, Textarea, useAviso, Vacio } from '../../components/ui'
import { api, lista } from '../../lib/api'
import { cn } from '../../lib/utils'
import { useEtapas } from './Clase'

type Edicion =
  | { tipo: 'unidad'; registro?: any }
  | { tipo: 'capacidad'; unidad: number; registro?: any }
  | { tipo: 'indicador'; capacidad: number; registro?: any }

const RUTA = { unidad: '/unidades/', capacidad: '/capacidades/', indicador: '/indicadores/' }

export default function Unidades({ asignacion, seccion }: { asignacion: number; seccion: number }) {
  const qc = useQueryClient()
  const avisar = useAviso()
  const unidades = useQuery({ queryKey: ['unidades', asignacion], queryFn: () => lista(`/unidades/?asignacion=${asignacion}`, true) })
  const etapas = useEtapas(seccion)
  const [abierta, setAbierta] = useState<number | null>(null)
  const [edicion, setEdicion] = useState<Edicion | null>(null)
  const [borrar, setBorrar] = useState<{ tipo: keyof typeof RUTA; id: number } | null>(null)

  const refrescar = () => qc.invalidateQueries({ queryKey: ['unidades', asignacion] })

  const eliminar = async () => {
    if (!borrar) return
    try {
      await api(`${RUTA[borrar.tipo]}${borrar.id}/`, { method: 'DELETE' })
      avisar('Eliminado')
      await refrescar()
    } catch (e) {
      avisar(e instanceof Error ? e.message : 'No se pudo eliminar.', 'error')
    }
    setBorrar(null)
  }

  if (unidades.isLoading) return <Cargando />
  const siguiente = (unidades.data?.length ?? 0) + 1

  return (
    <div>
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="text-grafito-500">Unidades con su competencia, capacidades e indicadores.</p>
        <Boton onClick={() => setEdicion({ tipo: 'unidad' })} className="shrink-0"><Plus className="size-5" /> Unidad</Boton>
      </div>

      {!unidades.data?.length && <Vacio titulo="Sin unidades cargadas" texto="Cargá la primera unidad con sus capacidades e indicadores en un solo paso." />}

      <div className="space-y-3">
        {unidades.data?.map((u: any) => {
          const open = abierta === u.id
          return (
            <section key={u.id} className="overflow-hidden rounded-xl border border-grafito-200 bg-white">
              <button onClick={() => setAbierta(open ? null : u.id)} className="flex w-full items-center gap-3 px-4 py-3.5 text-left">
                <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-tinta-100 font-bold text-tinta-700">{u.numero}</span>
                <span className="min-w-0 flex-1">
                  <span className="block font-bold leading-snug">{u.titulo}</span>
                  <span className="text-sm text-grafito-500">{u.capacidades.length} capacidades · {u.capacidades.reduce((s: number, c: any) => s + c.indicadores.length, 0)} indicadores</span>
                </span>
                <ChevronDown className={cn('size-5 text-grafito-500 transition-transform', open && 'rotate-180')} />
              </button>

              {open && (
                <div className="border-t border-grafito-100 px-4 pb-4 pt-3">
                  {u.competencia && <p className="mb-3 text-grafito-600"><b className="text-tinta-700">Competencia: </b>{u.competencia}</p>}
                  <ol className="space-y-3">
                    {u.capacidades.map((c: any, ci: number) => (
                      <li key={c.id} className="rounded-lg bg-grafito-100/60 p-3">
                        <div className="flex items-start gap-2">
                          <p className="flex-1 font-bold"><span className="text-grafito-500">{ci + 1}.</span> {c.descripcion}</p>
                          <Mini onClick={() => setEdicion({ tipo: 'capacidad', unidad: u.id, registro: c })} etiqueta="Editar capacidad"><Pencil className="size-4" /></Mini>
                          <Mini onClick={() => setBorrar({ tipo: 'capacidad', id: c.id })} etiqueta="Eliminar capacidad"><Trash2 className="size-4" /></Mini>
                        </div>
                        <ul className="ml-5 mt-1 space-y-1">
                          {c.indicadores.map((i: any) => (
                            <li key={i.id} className="flex items-start gap-2 text-grafito-600">
                              <span className="mt-2 size-1.5 shrink-0 rounded-full bg-tinta-500" />
                              <span className="flex-1">{i.descripcion}</span>
                              <Mini onClick={() => setEdicion({ tipo: 'indicador', capacidad: c.id, registro: i })} etiqueta="Editar indicador"><Pencil className="size-3.5" /></Mini>
                              <Mini onClick={() => setBorrar({ tipo: 'indicador', id: i.id })} etiqueta="Eliminar indicador"><X className="size-4" /></Mini>
                            </li>
                          ))}
                        </ul>
                        <button onClick={() => setEdicion({ tipo: 'indicador', capacidad: c.id })} className="ml-5 mt-1 text-sm font-bold text-tinta-600">+ Indicador</button>
                      </li>
                    ))}
                  </ol>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Boton variante="secundario" onClick={() => setEdicion({ tipo: 'capacidad', unidad: u.id })}><Plus className="size-4" /> Capacidad</Boton>
                    <Boton variante="fantasma" onClick={() => setEdicion({ tipo: 'unidad', registro: u })}><Pencil className="size-4" /> Editar unidad</Boton>
                    <Boton variante="fantasma" className="text-ausente" onClick={() => setBorrar({ tipo: 'unidad', id: u.id })}><Trash2 className="size-4" /> Eliminar</Boton>
                  </div>
                </div>
              )}
            </section>
          )
        })}
      </div>

      {edicion?.tipo === 'unidad' && !edicion.registro && (
        <NuevaUnidad asignacion={asignacion} numero={siguiente} etapas={etapas.data?.etapas ?? []} etapaActual={etapas.data?.actual?.id}
          onCerrar={() => setEdicion(null)} onGuardada={(id) => { void refrescar(); setAbierta(id) }} />
      )}
      {edicion && (edicion.tipo !== 'unidad' || edicion.registro) && (
        <EditarSimple edicion={edicion} etapas={etapas.data?.etapas ?? []} asignacion={asignacion}
          onCerrar={() => setEdicion(null)} onGuardado={() => void refrescar()} />
      )}
      <Confirmar abierta={!!borrar} titulo="Eliminar" onCerrar={() => setBorrar(null)} onConfirmar={eliminar}
        texto={borrar?.tipo === 'unidad' ? 'Se eliminará la unidad con todas sus capacidades e indicadores.' : 'Esta acción no se puede deshacer.'} />
    </div>
  )
}

function Mini({ onClick, etiqueta, children }: { onClick: () => void; etiqueta: string; children: React.ReactNode }) {
  return (
    <button onClick={onClick} aria-label={etiqueta} className="grid size-8 shrink-0 place-items-center rounded-full text-grafito-500 hover:bg-white">
      {children}
    </button>
  )
}

/** Alta de unidad completa: competencia + capacidades + indicadores en un paso. */
function NuevaUnidad({ asignacion, numero, etapas, etapaActual, onCerrar, onGuardada }: {
  asignacion: number; numero: number; etapas: any[]; etapaActual?: number; onCerrar: () => void; onGuardada: (id: number) => void
}) {
  const avisar = useAviso()
  const [u, setU] = useState({ numero, titulo: '', competencia: '', etapa: etapaActual ?? null as number | null })
  const [caps, setCaps] = useState<{ descripcion: string; indicadores: string[] }[]>([{ descripcion: '', indicadores: [''] }])
  const [guardando, setGuardando] = useState(false)
  const [error, setError] = useState('')

  const setCap = (i: number, c: Partial<{ descripcion: string; indicadores: string[] }>) =>
    setCaps((cs) => cs.map((x, j) => (j === i ? { ...x, ...c } : x)))

  const guardar = async (e: React.FormEvent) => {
    e.preventDefault()
    setGuardando(true)
    setError('')
    try {
      const r = await api('/unidades/', {
        method: 'POST',
        body: {
          ...u, asignacion,
          capacidades: caps.filter((c) => c.descripcion.trim()).map((c) => ({
            descripcion: c.descripcion.trim(),
            indicadores: c.indicadores.filter((i) => i.trim()).map((i) => ({ descripcion: i.trim() })),
          })),
        },
      })
      avisar('Unidad guardada')
      onGuardada(r.id)
      onCerrar()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo guardar.')
    } finally {
      setGuardando(false)
    }
  }

  return (
    <Hoja abierta titulo="Nueva unidad" onCerrar={onCerrar}
      pie={<Boton type="submit" form="form-unidad" className="flex-1" cargando={guardando}>Guardar unidad</Boton>}>
      <form id="form-unidad" onSubmit={guardar} className="space-y-4">
        <div className="grid grid-cols-[5rem_1fr] gap-3">
          <Campo label="N°"><Input type="number" inputMode="numeric" value={u.numero} onChange={(e) => setU({ ...u, numero: Number(e.target.value) })} required /></Campo>
          <Campo label="Título de la unidad"><Input value={u.titulo} onChange={(e) => setU({ ...u, titulo: e.target.value })} required /></Campo>
        </div>
        {etapas.length > 0 && (
          <Campo label="Etapa">
            <Select value={u.etapa ?? ''} onChange={(e) => setU({ ...u, etapa: e.target.value ? Number(e.target.value) : null })}>
              <option value="">—</option>
              {etapas.map((e) => <option key={e.id} value={e.id}>{e.numero}ª {e.nombre}</option>)}
            </Select>
          </Campo>
        )}
        <Campo label="Competencia"><Textarea value={u.competencia} onChange={(e) => setU({ ...u, competencia: e.target.value })} /></Campo>

        {caps.map((c, i) => (
          <fieldset key={i} className="rounded-xl border border-grafito-200 p-3">
            <div className="mb-2 flex items-center justify-between">
              <legend className="font-bold text-tinta-700">Capacidad {i + 1}</legend>
              {caps.length > 1 && <button type="button" onClick={() => setCaps(caps.filter((_, j) => j !== i))} className="text-sm font-bold text-ausente">Quitar</button>}
            </div>
            <Textarea rows={2} placeholder="Descripción de la capacidad" value={c.descripcion} onChange={(e) => setCap(i, { descripcion: e.target.value })} />
            <p className="mb-1 mt-3 text-sm font-bold text-grafito-600">Indicadores</p>
            <div className="space-y-2">
              {c.indicadores.map((ind, k) => (
                <div key={k} className="flex gap-2">
                  <Input placeholder={`Indicador ${k + 1}`} value={ind}
                    onChange={(e) => setCap(i, { indicadores: c.indicadores.map((x, j) => (j === k ? e.target.value : x)) })} />
                  {c.indicadores.length > 1 && (
                    <button type="button" aria-label="Quitar indicador" onClick={() => setCap(i, { indicadores: c.indicadores.filter((_, j) => j !== k) })}
                      className="grid size-11 shrink-0 place-items-center rounded-control text-grafito-500 hover:bg-grafito-100"><X className="size-4" /></button>
                  )}
                </div>
              ))}
            </div>
            <button type="button" onClick={() => setCap(i, { indicadores: [...c.indicadores, ''] })} className="mt-2 text-sm font-bold text-tinta-600">+ Indicador</button>
          </fieldset>
        ))}
        <Boton type="button" variante="secundario" className="w-full" onClick={() => setCaps([...caps, { descripcion: '', indicadores: [''] }])}>
          <Plus className="size-4" /> Otra capacidad
        </Boton>
        {error && <p className="rounded-control bg-ausente-50 px-4 py-3 text-ausente">{error}</p>}
      </form>
    </Hoja>
  )
}

/** Edición de unidad (sus datos), capacidad o indicador. */
function EditarSimple({ edicion, etapas, asignacion, onCerrar, onGuardado }: {
  edicion: Edicion; etapas: any[]; asignacion: number; onCerrar: () => void; onGuardado: () => void
}) {
  const avisar = useAviso()
  const r = edicion.registro
  const [v, setV] = useState<any>(r ? { ...r } : { descripcion: '' })
  const [guardando, setGuardando] = useState(false)
  const titulo = { unidad: 'Editar unidad', capacidad: r ? 'Editar capacidad' : 'Nueva capacidad', indicador: r ? 'Editar indicador' : 'Nuevo indicador' }[edicion.tipo]

  const guardar = async (e: React.FormEvent) => {
    e.preventDefault()
    setGuardando(true)
    try {
      let body: any
      if (edicion.tipo === 'unidad') body = { numero: v.numero, titulo: v.titulo, competencia: v.competencia, etapa: v.etapa, asignacion }
      else if (edicion.tipo === 'capacidad') body = { descripcion: v.descripcion, unidad: edicion.unidad }
      else body = { descripcion: v.descripcion, capacidad: edicion.capacidad }
      await api(r ? `${RUTA[edicion.tipo]}${r.id}/` : RUTA[edicion.tipo], { method: r ? 'PATCH' : 'POST', body })
      avisar('Guardado')
      onGuardado()
      onCerrar()
    } catch (err) {
      avisar(err instanceof Error ? err.message : 'No se pudo guardar.', 'error')
    } finally {
      setGuardando(false)
    }
  }

  return (
    <Hoja abierta titulo={titulo} onCerrar={onCerrar}
      pie={<Boton type="submit" form="form-simple" className="flex-1" cargando={guardando}>Guardar</Boton>}>
      <form id="form-simple" onSubmit={guardar} className="space-y-4">
        {edicion.tipo === 'unidad' ? (
          <>
            <div className="grid grid-cols-[5rem_1fr] gap-3">
              <Campo label="N°"><Input type="number" value={v.numero} onChange={(e) => setV({ ...v, numero: Number(e.target.value) })} required /></Campo>
              <Campo label="Título"><Input value={v.titulo} onChange={(e) => setV({ ...v, titulo: e.target.value })} required /></Campo>
            </div>
            {etapas.length > 0 && (
              <Campo label="Etapa">
                <Select value={v.etapa ?? ''} onChange={(e) => setV({ ...v, etapa: e.target.value ? Number(e.target.value) : null })}>
                  <option value="">—</option>
                  {etapas.map((e) => <option key={e.id} value={e.id}>{e.numero}ª {e.nombre}</option>)}
                </Select>
              </Campo>
            )}
            <Campo label="Competencia"><Textarea value={v.competencia} onChange={(e) => setV({ ...v, competencia: e.target.value })} /></Campo>
          </>
        ) : (
          <Campo label="Descripción"><Textarea value={v.descripcion} onChange={(e) => setV({ ...v, descripcion: e.target.value })} required autoFocus /></Campo>
        )}
      </form>
    </Hoja>
  )
}
