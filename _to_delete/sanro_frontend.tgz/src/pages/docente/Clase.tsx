import { useQuery } from '@tanstack/react-query'
import { ChevronLeft } from 'lucide-react'
import { Link, useParams, useSearchParams } from 'react-router'
import { Cargando, ErrorCaja, Input } from '../../components/ui'
import { api, lista } from '../../lib/api'
import { hoyISO } from '../../lib/utils'
import { Pestanias } from '../gestion/Detalles'
import Anecdotico from './Anecdotico'
import Desarrollo from './Desarrollo'
import LlamarLista from './LlamarLista'
import Trabajos from './Trabajos'
import Unidades from './Unidades'

type Tab = 'lista' | 'desarrollo' | 'unidades' | 'trabajos' | 'anecdotico'

/** Datos compartidos por las pestañas de una clase. */
export function useClase(id: number) {
  const asignacion = useQuery({ queryKey: ['asignacion', id], queryFn: () => api(`/asignaciones/${id}/`, { cache: true }) })
  const alumnos = useQuery({ queryKey: ['lista-alumnos', id], queryFn: () => api(`/asignaciones/${id}/lista/`, { cache: true }) })
  return { asignacion, alumnos }
}

/** Etapas del año de la sección, y la que corresponde a hoy. */
export function useEtapas(seccionId?: number) {
  return useQuery({
    queryKey: ['etapas-seccion', seccionId],
    enabled: !!seccionId,
    queryFn: async () => {
      const s = await api(`/secciones/${seccionId}/`, { cache: true })
      const etapas = await lista(`/etapas/?anio_lectivo=${s.anio_lectivo}`, true)
      const hoy = hoyISO()
      const actual = etapas.find((e: any) => e.fecha_inicio <= hoy && hoy <= e.fecha_fin) ?? etapas[etapas.length - 1]
      return { etapas, actual }
    },
  })
}

export default function Clase() {
  const id = Number(useParams().id)
  const [params, setParams] = useSearchParams()
  const tab = (params.get('t') as Tab) || 'lista'
  const fecha = params.get('fecha') || hoyISO()
  const { asignacion } = useClase(id)

  const ir = (t: Tab) => setParams((p) => { p.set('t', t); return p }, { replace: true })
  const cambiarFecha = (f: string) => setParams((p) => { p.set('fecha', f || hoyISO()); return p }, { replace: true })

  if (asignacion.isLoading) return <Cargando />
  if (asignacion.error) return <ErrorCaja error={asignacion.error} />
  const a = asignacion.data

  return (
    <div>
      <div className="mb-4 flex items-start gap-2">
        <Link to="/clases" className="-ml-2 mt-0.5 grid size-10 shrink-0 place-items-center rounded-full hover:bg-grafito-100" aria-label="Volver">
          <ChevronLeft className="size-6" />
        </Link>
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-bold leading-tight">{a.materia_nombre}</h1>
          <p className="text-grafito-500">{a.seccion_descripcion}</p>
        </div>
      </div>

      <Pestanias valor={tab} onChange={ir} opciones={[
        { valor: 'lista', label: 'Lista' },
        { valor: 'desarrollo', label: 'Desarrollo' },
        { valor: 'trabajos', label: 'Trabajos' },
        { valor: 'unidades', label: 'Unidades' },
        { valor: 'anecdotico', label: 'Anecdótico' },
      ]} />

      {(tab === 'lista' || tab === 'desarrollo') && (
        <div className="mb-4 flex items-center gap-3">
          <label htmlFor="fecha-clase" className="text-sm font-bold text-grafito-600">Fecha de la clase</label>
          <Input id="fecha-clase" type="date" value={fecha} max={hoyISO()} onChange={(e) => cambiarFecha(e.target.value)} className="w-auto" />
        </div>
      )}

      {tab === 'lista' && <LlamarLista asignacion={id} fecha={fecha} onContinuar={() => ir('desarrollo')} />}
      {tab === 'desarrollo' && <Desarrollo asignacion={id} fecha={fecha} irALista={() => ir('lista')} irAUnidades={() => ir('unidades')} />}
      {tab === 'unidades' && <Unidades asignacion={id} seccion={a.seccion} />}
      {tab === 'trabajos' && <Trabajos asignacion={id} seccion={a.seccion} />}
      {tab === 'anecdotico' && <Anecdotico asignacion={id} />}
    </div>
  )
}
