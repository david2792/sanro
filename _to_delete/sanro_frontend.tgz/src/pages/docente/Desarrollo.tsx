import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Boton, Campo, Cargando, Casilla, Select, Tarjeta, Textarea, useAviso, Vacio } from '../../components/ui'
import { api, lista } from '../../lib/api'
import { cn } from '../../lib/utils'

/** Lo que el docente desarrolló en la clase: unidad, capacidades e indicadores. */
export default function Desarrollo({ asignacion, fecha, irALista, irAUnidades }: {
  asignacion: number; fecha: string; irALista: () => void; irAUnidades: () => void
}) {
  const qc = useQueryClient()
  const avisar = useAviso()

  const sesion = useQuery({
    queryKey: ['sesion', asignacion, fecha],
    queryFn: async () => (await api(`/sesiones/?asignacion=${asignacion}&fecha=${fecha}`)).results[0] ?? null,
  })
  const registro = useQuery({
    queryKey: ['registro-clase', sesion.data?.id],
    enabled: !!sesion.data?.id,
    queryFn: async () => (await api(`/registros-clase/?sesion=${sesion.data.id}`)).results[0] ?? null,
  })
  const unidades = useQuery({ queryKey: ['unidades', asignacion], queryFn: () => lista(`/unidades/?asignacion=${asignacion}`, true) })

  const [form, setForm] = useState<any>(null)
  const [cargadoPara, setCargadoPara] = useState<string>('')
  const [guardando, setGuardando] = useState(false)

  const clave = `${sesion.data?.id}-${registro.data?.id ?? 'nuevo'}`
  if (sesion.data && !registro.isLoading && unidades.data && cargadoPara !== clave) {
    const r = registro.data
    setForm({
      unidad: r?.unidad ?? unidades.data?.[unidades.data.length - 1]?.id ?? null,
      capacidades: r?.capacidades ?? [],
      indicadores_evaluados: r?.indicadores_evaluados ?? [],
      contenido: r?.contenido ?? '',
      actividades: r?.actividades ?? '',
      observaciones: r?.observaciones ?? '',
    })
    setCargadoPara(clave)
  }

  if (sesion.isLoading || unidades.isLoading) return <Cargando />
  if (!sesion.data)
    return <Vacio titulo="Primero guardá la lista de este día" texto="El desarrollo de la clase se registra sobre la clase en la que llamaste lista."
      accion={<Boton onClick={irALista}>Ir a la lista</Boton>} />
  if (!form) return <Cargando />

  const unidad = unidades.data?.find((u: any) => u.id === form.unidad)
  const alternar = (campo: 'capacidades' | 'indicadores_evaluados', id: number, on: boolean) =>
    setForm((f: any) => ({ ...f, [campo]: on ? [...f[campo], id] : f[campo].filter((x: number) => x !== id) }))

  const guardar = async () => {
    setGuardando(true)
    try {
      const body = { ...form, sesion: sesion.data.id }
      const r = registro.data
        ? await api(`/registros-clase/${registro.data.id}/`, { method: 'PATCH', body })
        : await api('/registros-clase/', { method: 'POST', body })
      qc.setQueryData(['registro-clase', sesion.data.id], r)
      avisar('Desarrollo de la clase guardado')
    } catch (e) {
      avisar(e instanceof Error ? e.message : 'No se pudo guardar.', 'error')
    } finally {
      setGuardando(false)
    }
  }

  return (
    <div className="space-y-5">
      {!unidades.data?.length ? (
        <Vacio titulo="Todavía no cargaste unidades" texto="Cargá tus unidades con capacidades e indicadores para marcarlos acá."
          accion={<Boton variante="secundario" onClick={irAUnidades}>Cargar unidades</Boton>} />
      ) : (
        <>
          <Campo label="Unidad desarrollada">
            <Select value={form.unidad ?? ''} onChange={(e) => setForm({ ...form, unidad: e.target.value ? Number(e.target.value) : null, capacidades: [], indicadores_evaluados: [] })}>
              <option value="">Sin unidad</option>
              {unidades.data.map((u: any) => <option key={u.id} value={u.id}>Unidad {u.numero}: {u.titulo}</option>)}
            </Select>
          </Campo>

          {unidad?.competencia && (
            <p className="rounded-control border-l-4 border-tinta-200 bg-tinta-50 px-4 py-3 text-grafito-600">
              <b className="text-tinta-700">Competencia: </b>{unidad.competencia}
            </p>
          )}

          {unidad && (
            <div>
              <p className="mb-2 text-sm font-bold text-grafito-600">Capacidades trabajadas e indicadores evaluados</p>
              {!unidad.capacidades.length && <p className="text-grafito-500">Esta unidad no tiene capacidades cargadas.</p>}
              <div className="space-y-3">
                {unidad.capacidades.map((c: any) => {
                  const marcada = form.capacidades.includes(c.id)
                  return (
                    <Tarjeta key={c.id} className={cn('px-4 py-2', marcada && 'border-tinta-500 ring-1 ring-tinta-500')}>
                      <Casilla checked={marcada} onChange={(on) => {
                        alternar('capacidades', c.id, on)
                        if (!on) setForm((f: any) => ({ ...f, capacidades: f.capacidades.filter((x: number) => x !== c.id),
                          indicadores_evaluados: f.indicadores_evaluados.filter((x: number) => !c.indicadores.some((i: any) => i.id === x)) }))
                      }}>
                        <span className="font-bold">{c.descripcion}</span>
                      </Casilla>
                      {marcada && c.indicadores.length > 0 && (
                        <div className="mb-1 ml-8 border-l-2 border-grafito-200 pl-3">
                          <p className="pt-1 text-xs font-bold text-grafito-500">Indicadores evaluados hoy (si evaluaste)</p>
                          {c.indicadores.map((i: any) => (
                            <Casilla key={i.id} checked={form.indicadores_evaluados.includes(i.id)} onChange={(on) => alternar('indicadores_evaluados', i.id, on)}>
                              {i.descripcion}
                            </Casilla>
                          ))}
                        </div>
                      )}
                    </Tarjeta>
                  )
                })}
              </div>
            </div>
          )}
        </>
      )}

      <Campo label="Contenido o tema desarrollado">
        <Textarea value={form.contenido} onChange={(e) => setForm({ ...form, contenido: e.target.value })} />
      </Campo>
      <Campo label="Actividades y estrategias">
        <Textarea value={form.actividades} onChange={(e) => setForm({ ...form, actividades: e.target.value })} />
      </Campo>
      <Campo label="Observaciones">
        <Textarea rows={2} value={form.observaciones} onChange={(e) => setForm({ ...form, observaciones: e.target.value })} />
      </Campo>

      <Boton grande className="w-full" onClick={guardar} cargando={guardando}>Guardar desarrollo</Boton>
    </div>
  )
}
