import { useQuery, useQueryClient } from '@tanstack/react-query'
import { CloudOff } from 'lucide-react'
import { useState } from 'react'
import { Boton, Cargando, ErrorCaja, useAviso, Vacio } from '../../components/ui'
import { api } from '../../lib/api'
import { guardarSesion, usePendientes } from '../../lib/offline'
import { cn, uuid } from '../../lib/utils'
import { useClase } from './Clase'

type Estado = 'P' | 'A' | 'T' | 'J'

const ESTILO: Record<Estado, { letra: string; nombre: string; circulo: string; texto: string }> = {
  P: { letra: 'P', nombre: 'Presente', circulo: 'bg-presente text-white', texto: 'text-grafito' },
  A: { letra: 'A', nombre: 'Ausente', circulo: 'bg-ausente text-white', texto: 'text-ausente' },
  T: { letra: 'T', nombre: 'Llegó tarde', circulo: 'bg-tarde text-white', texto: 'text-tarde' },
  J: { letra: 'J', nombre: 'Justificado', circulo: 'bg-justificado text-white', texto: 'text-justificado' },
}
// Un toque avanza al siguiente estado.
const SIGUIENTE: Record<Estado, Estado> = { P: 'A', A: 'T', T: 'P', J: 'P' }

export default function LlamarLista({ asignacion, fecha, onContinuar }: { asignacion: number; fecha: string; onContinuar: () => void }) {
  const qc = useQueryClient()
  const avisar = useAviso()
  const { alumnos } = useClase(asignacion)
  const pendientes = usePendientes()
  const pendiente = pendientes.find((p) => p.body.asignacion === asignacion && p.body.fecha === fecha)

  const existente = useQuery({
    queryKey: ['sesion', asignacion, fecha],
    queryFn: async () => (await api(`/sesiones/?asignacion=${asignacion}&fecha=${fecha}`)).results[0] ?? null,
    retry: false,
  })

  const clave = `${asignacion}-${fecha}-${existente.data?.id ?? 'nueva'}-${pendiente ? 'p' : ''}`
  const [cargadoPara, setCargadoPara] = useState('')
  const [estados, setEstados] = useState<Record<number, Estado>>({})
  const [id, setId] = useState(uuid())
  const [guardando, setGuardando] = useState(false)
  const [guardada, setGuardada] = useState(false)

  // Al cambiar de fecha o llegar datos, se carga lo guardado o todos presentes.
  const listo = alumnos.data && !existente.isLoading
  if (listo && cargadoPara !== clave) {
    const base: Record<number, Estado> = {}
    for (const a of alumnos.data) base[a.matricula] = 'P'
    const previo = pendiente?.body ?? existente.data
    for (const r of previo?.registros ?? []) base[r.matricula] = r.estado
    setEstados(base)
    setId(previo?.uuid ?? uuid())
    setGuardada(!!previo)
    setCargadoPara(clave)
  }

  if (alumnos.isLoading || existente.isLoading) return <Cargando />
  if (alumnos.error) return <ErrorCaja error={alumnos.error} />
  if (!alumnos.data?.length) return <Vacio titulo="Esta sección no tiene alumnos matriculados" texto="Secretaría debe matricularlos para poder llamar lista." />

  const cuenta = (e: Estado) => Object.values(estados).filter((x) => x === e).length
  const cambiar = (m: number) => {
    setEstados((s) => ({ ...s, [m]: SIGUIENTE[s[m] ?? 'P'] }))
    setGuardada(false)
  }
  const todosPresentes = () => {
    setEstados((s) => Object.fromEntries(Object.entries(s).map(([k, v]) => [k, v === 'J' ? 'J' : 'P'])))
    setGuardada(false)
  }

  const guardar = async () => {
    setGuardando(true)
    try {
      const ahora = new Date()
      const body = {
        uuid: id,
        asignacion,
        fecha,
        hora_inicio: existente.data?.hora_inicio ?? `${String(ahora.getHours()).padStart(2, '0')}:${String(ahora.getMinutes()).padStart(2, '0')}`,
        registros: alumnos.data.map((a: any) => ({ matricula: a.matricula, estado: estados[a.matricula] ?? 'P' })),
      }
      const r = await guardarSesion(body)
      setGuardada(true)
      if (r.offline) avisar('Sin señal: la lista quedó guardada en el teléfono y se enviará sola.', 'info')
      else {
        avisar('Lista guardada')
        qc.setQueryData(['sesion', asignacion, fecha], r.data)
        void qc.invalidateQueries({ queryKey: ['sesiones-hoy'] })
      }
    } catch (e) {
      avisar(e instanceof Error ? e.message : 'No se pudo guardar la lista.', 'error')
    } finally {
      setGuardando(false)
    }
  }

  return (
    <div>
      {pendiente && (
        <p className="mb-3 flex items-center gap-2 rounded-control bg-tarde-50 px-4 py-2.5 text-sm font-bold text-tarde">
          <CloudOff className="size-4 shrink-0" />
          {pendiente.error ? `No se pudo enviar: ${pendiente.error}` : 'Esta lista está en el teléfono, esperando señal para enviarse.'}
        </p>
      )}

      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="text-sm text-grafito-500">Tocá a un alumno para cambiar: presente, ausente, tarde.</p>
        <button onClick={todosPresentes} className="shrink-0 text-sm font-bold text-tinta-600">Todos presentes</button>
      </div>

      {/* La hoja del cuaderno: cada renglón es un alumno. */}
      <ol className="hoja-rayada overflow-hidden rounded-xl border border-grafito-200">
        {alumnos.data.map((a: any, i: number) => {
          const e = estados[a.matricula] ?? 'P'
          const est = ESTILO[e]
          return (
            <li key={a.matricula}>
              <button onClick={() => cambiar(a.matricula)} aria-label={`${a.alumno}: ${est.nombre}. Tocar para cambiar.`}
                className="flex h-16 w-full items-center text-left active:bg-tinta-50/70">
                <span className="w-11 shrink-0 pr-2 text-right text-sm font-bold text-grafito-500">{a.numero_lista ?? i + 1}</span>
                <span className="min-w-0 flex-1 pl-4">
                  <span className={cn('block truncate text-[17px] font-bold', est.texto, e === 'A' && 'line-through decoration-2')}>{a.alumno}</span>
                  {e !== 'P' && <span className={cn('block text-sm', est.texto)}>{est.nombre}</span>}
                </span>
                <span className={cn('mr-4 grid size-11 shrink-0 place-items-center rounded-full text-lg font-bold transition-colors', est.circulo)}>
                  {est.letra}
                </span>
              </button>
            </li>
          )
        })}
      </ol>

      {/* Barra para guardar, siempre a mano con el pulgar. */}
      <div className="sticky bottom-[5.25rem] z-20 mt-4 lg:bottom-4">
        <div className="flex items-center gap-3 rounded-2xl bg-grafito px-4 py-3 text-white shadow-xl">
          <div className="flex flex-1 gap-3 text-sm font-bold">
            <span><span className="text-lg">{cuenta('P')}</span> P</span>
            <span className="text-[#ff8f88]"><span className="text-lg">{cuenta('A')}</span> A</span>
            <span className="text-[#ffc861]"><span className="text-lg">{cuenta('T')}</span> T</span>
            {cuenta('J') > 0 && <span className="text-[#9cc8f2]"><span className="text-lg">{cuenta('J')}</span> J</span>}
          </div>
          {guardada ? (
            <Boton variante="secundario" onClick={onContinuar} className="ring-0">Registrar desarrollo</Boton>
          ) : (
            <Boton variante="secundario" onClick={guardar} cargando={guardando} className="ring-0">Guardar lista</Boton>
          )}
        </div>
      </div>
    </div>
  )
}
