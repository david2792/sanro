import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router'
import { useState } from 'react'
import { Cargando, Encabezado, ErrorCaja, Etiqueta, Input, Tarjeta, Vacio } from '../../components/ui'
import { api } from '../../lib/api'
import { fechaLarga, hoyISO } from '../../lib/utils'

/** Tablero del director: lo que pasó hoy en el colegio. */
export default function Tablero() {
  const [fecha, setFecha] = useState(hoyISO())
  const { data, isLoading, error } = useQuery({
    queryKey: ['resumen-dia', fecha],
    queryFn: () => api(`/reportes/resumen-dia/?fecha=${fecha}`),
    refetchInterval: 60_000,
  })

  const ausentes = data?.clases.reduce((s: number, c: any) => s + c.ausentes, 0) ?? 0
  const alumnosLista = data?.clases.reduce((s: number, c: any) => s + c.alumnos, 0) ?? 0

  return (
    <div>
      <Encabezado
        titulo="Tablero del día"
        detalle={<span className="block first-letter:uppercase">{fechaLarga(fecha)}</span>}
        acciones={<Input type="date" value={fecha} onChange={(e) => setFecha(e.target.value || hoyISO())} className="w-auto" aria-label="Fecha" />}
      />
      {isLoading && <Cargando />}
      <ErrorCaja error={error} />
      {data && (
        <>
          <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Dato valor={data.clases.length} texto="clases con lista" />
            <Dato valor={ausentes} texto={`ausencias en ${alumnosLista} registros`} tono={ausentes ? 'text-ausente' : undefined} />
            <Dato valor={data.docentes_con_clase.length} texto="docentes registraron clase" />
            <Dato valor={data.docentes_sin_registro.length} texto="docentes sin registro" tono={data.docentes_sin_registro.length ? 'text-tarde' : undefined} />
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <section className="min-w-0 lg:col-span-2">
              <h2 className="mb-3 text-lg font-bold">Clases registradas</h2>
              {!data.clases.length ? (
                <Vacio titulo="Todavía no hay listas en esta fecha" texto="Las clases aparecen acá apenas cada docente guarda su lista." />
              ) : (
                <ul className="divide-y divide-grafito-100 overflow-hidden rounded-xl border border-grafito-200 bg-white">
                  {data.clases.map((c: any) => (
                    <li key={c.sesion} className="flex items-center gap-3 px-4 py-3">
                      <span className="w-12 shrink-0 text-sm font-bold text-grafito-500">{c.hora_inicio?.slice(0, 5) ?? '—'}</span>
                      <div className="min-w-0 flex-1">
                        <p className="font-bold">{c.materia}</p>
                        <p className="truncate text-sm text-grafito-500">{c.seccion} · {c.docente}</p>
                      </div>
                      <div className="flex gap-1.5">
                        {c.ausentes > 0 && <Etiqueta tono="rojo">{c.ausentes} A</Etiqueta>}
                        {c.tardanzas > 0 && <Etiqueta tono="ambar">{c.tardanzas} T</Etiqueta>}
                        {!c.ausentes && !c.tardanzas && <Etiqueta tono="verde">Completo</Etiqueta>}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section className="min-w-0 space-y-4">
              <ListaDocentes titulo="Sin registro de clase" nombres={data.docentes_sin_registro} tono="ambar"
                nota="Sin el módulo de horarios se listan quienes no abrieron ninguna clase en la fecha." />
              <ListaDocentes titulo="Con permiso o licencia" nombres={data.docentes_con_permiso} tono="azul" />
              <ListaDocentes titulo="Registraron clase" nombres={data.docentes_con_clase} tono="verde" />
              <Link to="/ref/secciones" className="block text-center font-bold text-tinta-600">Ver asistencia por sección</Link>
            </section>
          </div>
        </>
      )}
    </div>
  )
}

function Dato({ valor, texto, tono }: { valor: number; texto: string; tono?: string }) {
  return (
    <Tarjeta className="px-4 py-3">
      <p className={`text-3xl font-bold ${tono ?? 'text-tinta-700'}`}>{valor}</p>
      <p className="text-sm leading-snug text-grafito-500">{texto}</p>
    </Tarjeta>
  )
}

function ListaDocentes({ titulo, nombres, tono, nota }: { titulo: string; nombres: string[]; tono: 'verde' | 'ambar' | 'azul'; nota?: string }) {
  return (
    <Tarjeta className="p-4">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="font-bold">{titulo}</h3>
        <Etiqueta tono={tono}>{nombres.length}</Etiqueta>
      </div>
      {nombres.length ? (
        <ul className="space-y-1 text-grafito-600">{nombres.map((n) => <li key={n}>{n}</li>)}</ul>
      ) : <p className="text-sm text-grafito-500">Nadie.</p>}
      {nota && <p className="mt-2 text-xs text-grafito-500">{nota}</p>}
    </Tarjeta>
  )
}
