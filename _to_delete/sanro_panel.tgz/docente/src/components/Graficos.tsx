import { useEffect, useRef, useState } from 'react'
import { cn, fechaCorta } from '../lib/utils'

/** Ancho del contenedor, para dibujar el SVG a escala real (texto nítido). */
function useAncho<T extends HTMLElement>() {
  const ref = useRef<T>(null)
  const [ancho, setAncho] = useState(0)
  useEffect(() => {
    if (!ref.current) return
    const ro = new ResizeObserver(([e]) => setAncho(e.contentRect.width))
    ro.observe(ref.current)
    return () => ro.disconnect()
  }, [])
  return [ref, ancho] as const
}

type Punto = { fecha: string; porcentaje: number | null; registros: number }

/**
 * Línea de asistencia diaria (una serie: el título la nombra, sin leyenda).
 * Línea de referencia en el mínimo exigido. Tooltip con cruz al pasar o tocar.
 */
export function LineaAsistencia({ datos, minimo, alto = 200 }: { datos: Punto[]; minimo: number; alto?: number }) {
  const [ref, ancho] = useAncho<HTMLDivElement>()
  const [activo, setActivo] = useState<number | null>(null)
  const pts = datos.filter((d) => d.porcentaje != null)

  if (pts.length < 2) {
    return <p className="py-10 text-center text-grafito-500">Hacen falta al menos dos días con listas para ver la evolución.</p>
  }

  const m = { izq: 34, der: 12, arr: 12, aba: 24 }
  const w = Math.max(ancho - m.izq - m.der, 10)
  const h = alto - m.arr - m.aba
  const minY = Math.max(0, Math.floor(Math.min(minimo, ...pts.map((p) => p.porcentaje!)) / 10) * 10 - 10)
  const y = (v: number) => m.arr + h - ((v - minY) / (100 - minY)) * h
  const x = (i: number) => m.izq + (pts.length === 1 ? w / 2 : (i * w) / (pts.length - 1))
  const linea = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i)},${y(p.porcentaje!)}`).join('')
  const area = `${linea}L${x(pts.length - 1)},${m.arr + h}L${x(0)},${m.arr + h}Z`
  const ticks = [minY, minY + (100 - minY) / 2, 100].map(Math.round)
  const ultimo = pts[pts.length - 1]

  const mover = (clientX: number) => {
    const r = ref.current!.getBoundingClientRect()
    const rel = clientX - r.left - m.izq
    setActivo(Math.max(0, Math.min(pts.length - 1, Math.round((rel / w) * (pts.length - 1)))))
  }

  const sel = activo != null ? pts[activo] : null
  return (
    <div ref={ref} className="relative select-none" onPointerLeave={() => setActivo(null)}>
      {ancho > 0 && (
        <svg width={ancho} height={alto} role="img" aria-label={`Asistencia diaria. Último día ${ultimo.porcentaje}%`}
          onPointerMove={(e) => mover(e.clientX)} onPointerDown={(e) => mover(e.clientX)} className="touch-pan-y">
          {ticks.map((t) => (
            <g key={t}>
              <line x1={m.izq} x2={m.izq + w} y1={y(t)} y2={y(t)} stroke="var(--color-grafito-200)" strokeWidth={1} />
              <text x={m.izq - 6} y={y(t) + 4} textAnchor="end" className="fill-grafito-500 text-[11px]" style={{ fontVariantNumeric: 'tabular-nums' }}>{t}</text>
            </g>
          ))}
          {/* Mínimo exigido */}
          <line x1={m.izq} x2={m.izq + w} y1={y(minimo)} y2={y(minimo)} stroke="var(--color-ausente)" strokeWidth={1} />
          <text x={m.izq + 6} y={y(minimo) + 14} className="fill-ausente text-[11px] font-bold" stroke="white" strokeWidth={3} paintOrder="stroke">Mínimo {minimo}%</text>

          <path d={area} fill="var(--color-tinta-600)" opacity={0.1} />
          <path d={linea} fill="none" stroke="var(--color-tinta-600)" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />

          <text x={m.izq} y={alto - 6} className="fill-grafito-500 text-[11px]">{fechaCorta(pts[0].fecha).slice(0, 5)}</text>
          <text x={m.izq + w} y={alto - 6} textAnchor="end" className="fill-grafito-500 text-[11px]">{fechaCorta(ultimo.fecha).slice(0, 5)}</text>

          {sel ? (
            <g>
              <line x1={x(activo!)} x2={x(activo!)} y1={m.arr} y2={m.arr + h} stroke="var(--color-grafito-300)" strokeWidth={1} />
              <circle cx={x(activo!)} cy={y(sel.porcentaje!)} r={5} fill="var(--color-tinta-600)" stroke="white" strokeWidth={2} />
            </g>
          ) : (
            <circle cx={x(pts.length - 1)} cy={y(ultimo.porcentaje!)} r={4.5} fill="var(--color-tinta-600)" stroke="white" strokeWidth={2} />
          )}
        </svg>
      )}
      {sel && (
        <div className="pointer-events-none absolute top-0 rounded-lg bg-grafito px-3 py-2 text-sm text-white shadow-lg"
          style={{ left: Math.min(Math.max(x(activo!) - 70, 0), ancho - 150) }}>
          <p className="font-bold">{fechaCorta(sel.fecha)}</p>
          <p>Asistencia {sel.porcentaje}%</p>
          <p className="text-grafito-300">{sel.registros} registros</p>
        </div>
      )}
    </div>
  )
}

/**
 * Barras horizontales de porcentaje con línea de mínimo.
 * Las que quedan debajo del mínimo se marcan con color y texto (nunca solo color).
 */
export function BarrasPorcentaje({ filas, minimo, etiquetaMinimo = 'Mínimo', onTocar }: {
  filas: { id: number | string; nombre: string; detalle?: string; valor: number | null }[]
  minimo: number
  etiquetaMinimo?: string
  onTocar?: (id: any) => void
}) {
  return (
    <div>
      <ul className="space-y-1">
        {filas.map((f) => {
          const bajo = f.valor != null && f.valor < minimo
          return (
            <li key={f.id}>
              <button onClick={() => onTocar?.(f.id)} disabled={!onTocar}
                className={cn('group w-full rounded-lg px-2 py-2 text-left', onTocar && 'hover:bg-tinta-50/60 active:bg-tinta-50')}>
                <div className="mb-1.5 flex items-baseline justify-between gap-3">
                  <span className="min-w-0 truncate font-bold">{f.nombre}</span>
                  <span className="shrink-0 font-bold" style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {f.valor == null ? <span className="font-normal text-grafito-500">Sin datos</span> : `${f.valor}%`}
                  </span>
                </div>
                <div className="relative h-2.5 rounded-full bg-grafito-100">
                  {f.valor != null && (
                    <div className={cn('h-full rounded-full', bajo ? 'bg-ausente' : 'bg-tinta-500')} style={{ width: `${Math.max(f.valor, 1.5)}%` }} />
                  )}
                  <div className="absolute -inset-y-1 w-0.5 rounded bg-grafito" style={{ left: `${minimo}%` }} title={`${etiquetaMinimo} ${minimo}%`} />
                </div>
                {(f.detalle || bajo) && (
                  <p className="mt-1 text-sm text-grafito-500">
                    {bajo && <span className="font-bold text-ausente">Debajo del mínimo{f.detalle ? ' · ' : ''}</span>}{f.detalle}
                  </p>
                )}
              </button>
            </li>
          )
        })}
      </ul>
      <p className="mt-2 flex items-center gap-2 px-2 text-xs text-grafito-500">
        <span className="inline-block h-3 w-0.5 rounded bg-grafito" /> {etiquetaMinimo} {minimo}%
      </p>
    </div>
  )
}
