from decimal import Decimal

from django.db.models import Count, Q
from rest_framework import viewsets
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response

from academico.models import Asignacion, Matricula
from academico.views import FiltroParamsMixin
from personas.permisos import EsPersonal
from .models import (Capacidad, Indicador, Instrumento, Puntaje, RegistroAnecdotico,
                     RegistroClase, Unidad)
from .serializers import (CapacidadSerializer, IndicadorSerializer, InstrumentoSerializer,
                          PuntajesLoteSerializer, RegistroAnecdoticoSerializer,
                          RegistroClaseSerializer, UnidadSerializer, verificar_asignacion)


class PropiasMixin(FiltroParamsMixin):
    """Docente: solo ve lo de sus asignaciones. Gestión: ve todo."""

    permission_classes = [EsPersonal]
    campo_docente = "asignacion__docente__usuario"

    def get_queryset(self):
        qs = super().get_queryset()
        if not self.request.user.es_gestion:
            qs = qs.filter(**{self.campo_docente: self.request.user})
        return qs


class UnidadViewSet(PropiasMixin, viewsets.ModelViewSet):
    """GET /api/unidades/?asignacion=5  -> unidades con capacidades e indicadores."""

    queryset = Unidad.objects.prefetch_related("capacidades__indicadores")
    serializer_class = UnidadSerializer
    filtros = ["asignacion", "etapa"]


class CapacidadViewSet(PropiasMixin, viewsets.ModelViewSet):
    queryset = Capacidad.objects.prefetch_related("indicadores")
    serializer_class = CapacidadSerializer
    filtros = ["unidad"]
    campo_docente = "unidad__asignacion__docente__usuario"


class IndicadorViewSet(PropiasMixin, viewsets.ModelViewSet):
    queryset = Indicador.objects.all()
    serializer_class = IndicadorSerializer
    filtros = ["capacidad", "capacidad__unidad"]
    campo_docente = "capacidad__unidad__asignacion__docente__usuario"


class RegistroClaseViewSet(PropiasMixin, viewsets.ModelViewSet):
    """
    POST /api/registros-clase/ {sesion, unidad, capacidades:[ids], indicadores_evaluados:[ids],
                                contenido, actividades, observaciones}
    GET  /api/registros-clase/?sesion__asignacion=5   -> cuaderno de cátedra de la materia
    """

    queryset = RegistroClase.objects.select_related("sesion", "unidad").prefetch_related(
        "capacidades", "indicadores_evaluados")
    serializer_class = RegistroClaseSerializer
    filtros = ["sesion", "sesion__asignacion", "unidad", "sesion__fecha"]
    campo_docente = "sesion__asignacion__docente__usuario"


class RegistroAnecdoticoViewSet(PropiasMixin, viewsets.ModelViewSet):
    """GET /api/anecdoticos/?alumnos__alumno=12  -> historial anecdótico de un alumno."""

    queryset = RegistroAnecdotico.objects.select_related(
        "asignacion__materia", "asignacion__seccion__curso", "registrado_por"
    ).prefetch_related("alumnos__alumno")
    serializer_class = RegistroAnecdoticoSerializer
    filtros = ["asignacion", "asignacion__seccion", "alumnos", "alumnos__alumno", "tipo", "fecha"]

    def get_queryset(self):
        return super().get_queryset().distinct()

    def perform_create(self, serializer):
        serializer.save(registrado_por=self.request.user)


class InstrumentoViewSet(PropiasMixin, viewsets.ModelViewSet):
    """
    GET  /api/instrumentos/?asignacion=5&etapa=1
    GET  /api/instrumentos/{id}/puntajes/  -> lista del curso con el puntaje de cada alumno
    POST /api/instrumentos/{id}/puntajes/  -> {puntajes: [{matricula, puntaje, observacion}]}
    """

    queryset = Instrumento.objects.select_related("etapa").annotate(
        evaluados=Count("puntajes", filter=Q(puntajes__puntaje__isnull=False)))
    serializer_class = InstrumentoSerializer
    filtros = ["asignacion", "etapa", "tipo"]

    @action(detail=True, methods=["get", "post"])
    def puntajes(self, request, pk=None):
        instrumento = self.get_object()
        if request.method == "POST":
            verificar_asignacion(request, instrumento.asignacion)
            s =PuntajesLoteSerializer(data=request.data,
                                       context={"request": request, "instrumento": instrumento})
            s.is_valid(raise_exception=True)
            s.save()

        cargados = {p.matricula_id: p for p in instrumento.puntajes.all()}
        matriculas = instrumento.asignacion.seccion.matriculas.filter(
            Q(estado=Matricula.Estado.ACTIVA) | Q(id__in=cargados.keys())
        ).select_related("alumno").order_by("numero_lista", "alumno__apellidos", "alumno__nombres")
        return Response({
            "instrumento": InstrumentoSerializer(instrumento, context={"request": request}).data,
            "alumnos": [{
                "matricula": m.id,
                "numero_lista": m.numero_lista,
                "alumno": str(m.alumno),
                "puntaje": cargados[m.id].puntaje if m.id in cargados else None,
                "observacion": cargados[m.id].observacion if m.id in cargados else "",
            } for m in matriculas],
        })


@api_view(["GET"])
@permission_classes([EsPersonal])
def planilla(request):
    """
    Planilla de puntajes de una materia en una etapa:
    GET /api/planilla/?asignacion=5&etapa=1
    Devuelve los trabajos (columnas) y, por alumno, el puntaje de cada uno,
    el total logrado, el total posible y el porcentaje de logro.
    """
    try:
        asignacion = Asignacion.objects.select_related("seccion").get(pk=request.query_params.get("asignacion"))
    except (Asignacion.DoesNotExist, ValueError, TypeError):
        raise ValidationError("Indicá una asignación válida (?asignacion=ID).")
    verificar_asignacion(request, asignacion)

    instrumentos = list(asignacion.instrumentos.all().order_by("fecha", "id"))
    etapa = request.query_params.get("etapa")
    if etapa:
        instrumentos = [i for i in instrumentos if str(i.etapa_id) == etapa]
    total_posible = sum((i.puntaje_total for i in instrumentos), Decimal("0"))

    notas = {}
    for p in Puntaje.objects.filter(instrumento__in=instrumentos):
        notas[(p.matricula_id, p.instrumento_id)] = p.puntaje

    filas = []
    matriculas = asignacion.seccion.matriculas.filter(estado=Matricula.Estado.ACTIVA).select_related(
        "alumno").order_by("numero_lista", "alumno__apellidos", "alumno__nombres")
    for m in matriculas:
        puntajes = [notas.get((m.id, i.id)) for i in instrumentos]
        logrado = sum((p for p in puntajes if p is not None), Decimal("0"))
        filas.append({
            "matricula": m.id,
            "numero_lista": m.numero_lista,
            "alumno": str(m.alumno),
            "puntajes": puntajes,
            "logrado": logrado,
            "porcentaje": float(round(logrado * 100 / total_posible, 1)) if total_posible else None,
        })

    return Response({
        "asignacion": str(asignacion),
        "trabajos": [{"id": i.id, "titulo": i.titulo, "tipo": i.get_tipo_display(),
                      "fecha": i.fecha, "puntaje_total": i.puntaje_total} for i in instrumentos],
        "total_posible": total_posible,
        "alumnos": filas,
    })
