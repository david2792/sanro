from datetime import date

from rest_framework.test import APITestCase

from academico.models import (AnioLectivo, Asignacion, Curso, Etapa, Materia, Matricula, Nivel,
                              Seccion)
from personas.models import Alumno, Docente, Usuario


class FlujoPedagogicoTest(APITestCase):
    def setUp(self):
        self.director = Usuario.objects.create_user("director", password="x", rol="DIRECTOR")
        self.u_doc = Usuario.objects.create_user("profe", password="x", rol="DOCENTE")
        self.u_otro = Usuario.objects.create_user("otro", password="x", rol="DOCENTE")
        doc = Docente.objects.create(usuario=self.u_doc, ci="1", nombres="Ana", apellidos="Gómez")
        Docente.objects.create(usuario=self.u_otro, ci="2", nombres="Luis", apellidos="Ruiz")
        anio = AnioLectivo.objects.create(anio=2027, fecha_inicio=date(2027, 2, 20),
                                          fecha_fin=date(2027, 12, 1), activo=True)
        self.etapa = Etapa.objects.create(anio_lectivo=anio, numero=1, nombre="Etapa",
                                          fecha_inicio=date(2027, 2, 20), fecha_fin=date(2027, 7, 1))
        curso = Curso.objects.create(nivel=Nivel.objects.create(nombre="EM"), grado=1, nombre="1° Curso")
        sec = Seccion.objects.create(anio_lectivo=anio, curso=curso)
        self.asig = Asignacion.objects.create(seccion=sec, materia=Materia.objects.create(nombre="Informática"),
                                              docente=doc)
        self.m = [Matricula.objects.create(alumno=Alumno.objects.create(ci=str(i), nombres="A", apellidos=f"X{i}"),
                                           seccion=sec, fecha=date(2027, 2, 20), numero_lista=i)
                  for i in (1, 2)]

    def login(self, u):
        r = self.client.post("/api/auth/token/", {"username": u.username, "password": "x"})
        self.client.credentials(HTTP_AUTHORIZATION="Bearer " + r.data["access"])

    def test_flujo(self):
        self.login(self.u_doc)
        # 1. Unidad completa en un POST
        r = self.client.post("/api/unidades/", {
            "asignacion": self.asig.id, "etapa": self.etapa.id, "numero": 1, "titulo": "Hojas de cálculo",
            "competencia": "Utiliza herramientas informáticas...",
            "capacidades": [{"descripcion": "Aplica fórmulas", "indicadores": [
                {"descripcion": "Escribe fórmulas básicas"}, {"descripcion": "Usa referencias"}]}],
        }, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        cap = r.data["capacidades"][0]
        ind1, ind2 = [i["id"] for i in cap["indicadores"]]

        # 2. Llama lista y registra lo desarrollado
        s = self.client.post("/api/sesiones/", {"asignacion": self.asig.id, "fecha": "2027-03-02",
                             "registros": [{"matricula": self.m[0].id, "estado": "P"}]}, format="json")
        rc = self.client.post("/api/registros-clase/", {
            "sesion": s.data["id"], "unidad": r.data["id"], "capacidades": [cap["id"]],
            "indicadores_evaluados": [ind1], "contenido": "Fórmulas SUMA y PROMEDIO"}, format="json")
        self.assertEqual(rc.status_code, 201, rc.data)

        # 3. Registro anecdótico
        an = self.client.post("/api/anecdoticos/", {
            "asignacion": self.asig.id, "alumnos": [self.m[1].id], "fecha": "2027-03-02",
            "tipo": "NEGATIVO", "hecho": "Usó el celular durante la prueba.",
            "acciones": "Se conversó con el alumno."}, format="json")
        self.assertEqual(an.status_code, 201, an.data)
        self.assertEqual(an.data["registrado_por"], self.u_doc.id)

        # 4. Trabajos con puntaje
        t1 = self.client.post("/api/instrumentos/", {
            "asignacion": self.asig.id, "etapa": self.etapa.id, "tipo": "PRACTICO", "titulo": "TP 1",
            "fecha": "2027-03-05", "puntaje_total": "10", "indicadores": [ind1, ind2]}, format="json")
        self.assertEqual(t1.status_code, 201, t1.data)
        t2 = self.client.post("/api/instrumentos/", {
            "asignacion": self.asig.id, "etapa": self.etapa.id, "tipo": "PRUEBA", "titulo": "Prueba 1",
            "fecha": "2027-03-10", "puntaje_total": "20"}, format="json")
        url = f"/api/instrumentos/{t1.data['id']}/puntajes/"
        malo = self.client.post(url, {"puntajes": [{"matricula": self.m[0].id, "puntaje": "11"}]}, format="json")
        self.assertEqual(malo.status_code, 400)
        print("excede:", malo.data)
        ok = self.client.post(url, {"puntajes": [{"matricula": self.m[0].id, "puntaje": "8"},
                                                 {"matricula": self.m[1].id, "puntaje": "5.5"}]}, format="json")
        self.assertEqual(ok.status_code, 200, ok.data)
        self.client.post(f"/api/instrumentos/{t2.data['id']}/puntajes/",
                         {"puntajes": [{"matricula": self.m[0].id, "puntaje": "18"}]}, format="json")
        pl = self.client.get(f"/api/planilla/?asignacion={self.asig.id}&etapa={self.etapa.id}").data
        print("planilla:", pl)
        self.assertEqual(pl["total_posible"], 30)
        self.assertEqual(pl["alumnos"][0]["porcentaje"], 86.7)  # 26/30

        # 5. Otro docente no ve ni modifica nada de esta materia
        self.login(self.u_otro)
        self.assertEqual(self.client.get("/api/unidades/").data["count"], 0)
        self.assertEqual(self.client.get("/api/anecdoticos/").data["count"], 0)
        self.assertEqual(self.client.post(url, {"puntajes": []}, format="json").status_code, 404)
        self.assertEqual(self.client.post("/api/instrumentos/", {
            "asignacion": self.asig.id, "etapa": self.etapa.id, "titulo": "x", "fecha": "2027-03-05",
            "puntaje_total": "5"}, format="json").status_code, 400)

        # 6. El director ve todo
        self.login(self.director)
        self.assertEqual(self.client.get(f"/api/anecdoticos/?alumnos__alumno={self.m[1].alumno_id}").data["count"], 1)
        self.assertEqual(self.client.get("/api/registros-clase/").data["count"], 1)
